<?php

App::uses('AppController', 'Controller');

class GroupChallengesController extends AppController {

    var $uses = array('User', 'Weight', 'SleepUserAnswer', 'SleepMatrix', 'SleepUserCompleted', 'Qscore', 'HraCategory', 'FitnessAnswer', 'UserPoint');
    var $components = array('RequestHandler', 'Session', 'Curl');

    public function getMycompanyUsers() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $Userid = $this->request->data['UserId'];
        $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $Userid)));
        $MyUsers = $this->User->find('all', array(
            'conditions' => array('User.company_id' => $UserData['User']['company_id'], 'User.opt_in_emp_group' => '1','User.id !=' => $UserData['User']['id']),
            'fields' => array('User.username', 'User.id','User.surname')));
        
    
      
        if (!empty($MyUsers)) {
            
            foreach ($MyUsers as $key => $value) {
                if($value['User']['surname'] == ''){
                    $surname = '';
                }else{
                    $surname = ucfirst($this->decrypt($value['User']['surname']));
                }
                $data[$key]['Username'] = ucfirst($this->decrypt($value['User']['username'])).' '.$surname;
                $data[$key]['id'] = $value['User']['id'];
            }
             asort($data);
          
           $Username = Set::classicExtract($data, '{n}.Username');
           $id = Set::classicExtract($data, '{n}.id');
            // print_r($data);die;
           for($i=0;$i<count($data);$i++){
               $Newdata[$i]['Username'] = $Username[$i];
               $Newdata[$i]['id'] = $id[$i];
           }
          // print_r($Newdata);die;
             echo json_encode($Newdata);
        } else {
            $data = '';
            echo json_encode($data);
        }
    }

    public function getMyFavUsers() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Star');
        $Userid = $this->request->data['UserId'];
        $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $Userid)));

        $MyfavUserIds = $this->Star->find('all', array(
            'conditions' => array('Star.user_id' => $UserData['User']['id'])));

        if (!empty($MyfavUserIds)) {
            foreach ($MyfavUserIds as $key => $value) {
                $FavUserData = $this->User->find('first', array('conditions' => array('User.id' => $value['Star']['star_id'])));
                
                if($FavUserData['User']['surname'] == ''){
                    $surname = '';
                }else{
                    $surname = ucfirst($this->decrypt($FavUserData['User']['surname']));
                }
                
                $data[$key]['Username'] = ucfirst($this->decrypt($FavUserData['User']['username'])).' '.$surname;
                $data[$key]['id'] = $FavUserData['User']['id'];
            }
            
             asort($data);
          
           $Username = Set::classicExtract($data, '{n}.Username');
           $id = Set::classicExtract($data, '{n}.id');
            // print_r($data);die;
           for($i=0;$i<count($data);$i++){
               $Newdata[$i]['Username'] = $Username[$i];
               $Newdata[$i]['id'] = $id[$i];
           }
          // print_r($Newdata);die;
             echo json_encode($Newdata);
        } else {
            $data = '';
            echo json_encode($data);
        }
    }

    public function CreateGroupChallenge() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        $this->loadModel('GroupMember');

        $Userid = $this->request->data['userId'];
        $Membersid = $this->request->data['members_id'];
        $GroupName = $this->request->data['group_name'];
        $Challenge_id = $this->request->data['challenge_id'];
        $Duration = $this->request->data['time_limit'];
        $endMoves = $this->request->data['endMoves'];
        $challenge_type = $this->request->data['challenge_type'];
        $group_challenge_type = $this->request->data['group_challenge_type'];
        
        $Emails = $this->request->data['email'];
        if(!empty($Emails)){
          $EmailArr = explode(",", $Emails);
                for ($i = 0; $i < sizeof($EmailArr); $i++) {
                    $userEmailData = $this->User->find('first', array('conditions' => array('User.email' => $EmailArr[$i])));
                        if(!empty($userEmailData)){
                           $Membersid = $Membersid.','.$userEmailData['User']['id'];
                           
                        }
                }  
        }
        
        $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $Userid)));
        $AdminName = $this->decrypt($UserData['User']['username']).' '.$this->decrypt($UserData['User']['surname']);
        $challengeDetails = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $Challenge_id)));
        $challengeName = $challengeDetails['Challenge']['challenges_name'];
        $data['user_id'] = $UserData['User']['id'];
        $data['groupname'] = $GroupName;
        $data['status'] = 1;
        $data['created'] = date('Y-m-d H:i:s');
        if ($this->request->is('post')) {
            if ($this->Group->save($data)) {
                $groupId = $this->Group->getLastInsertID();
                
                $IdArr = explode(",", $Membersid);
                 for ($i = 0; $i < sizeof($IdArr); $i++) {
                
                $groupData['user_id'] = $IdArr[$i];
                $groupData['groups_id'] = $groupId;
                $groupData['challenges_id'] = $Challenge_id;
                $groupData['challenge_type'] = $challenge_type;
                $groupData['group_challenge_type'] = $group_challenge_type;
                $groupData['status'] = 3;
                $groupData['end_moves'] = $endMoves;
                 $this->GroupChallenge->create();
                if ($this->GroupChallenge->save($groupData)) {
                    $groupChallengesId = $this->GroupChallenge->getLastInsertID();
                   
                   
                        $groupInvitesData['groups_id'] = $groupId;
                        $groupMemberData['groups_id'] = $groupId;
                        $groupInvitesData['group_challenges_id'] = $groupChallengesId;
                        $groupInvitesData['challenges_id'] = $Challenge_id;
                        $groupInvitesData['user_id'] = $IdArr[$i];  // id of group invites
                        $groupMemberData['user_id'] = $IdArr[$i];  // id of group invites
                        if ($IdArr[$i] == $UserData['User']['id']) {
                            $groupInvitesData['status'] = 1;
                        }else{
                            $groupInvitesData['status'] = 2;
                        }
                        
                        
                         $groupInvitesData['invitation_sent_on'] = date('Y-m-d H:i:s');
                         if ($IdArr[$i] == $UserData['User']['id']) {
                             $groupMemberData['status'] = 1;
                         }else{
                             $groupMemberData['status'] = 2;
                         }
                        
                        $groupMemberData['invitation_sent_on'] = date('Y-m-d H:i:s');
                        $this->GroupChallengeInvite->create();
                        $this->GroupChallengeInvite->save($groupInvitesData);
                        $this->GroupMember->create();
                        $this->GroupMember->save($groupMemberData);
                        $userDataEmail = $this->User->find('first', array('conditions' => array('User.id' => $IdArr[$i])));
                        
//                         if($userDataEmail['User']['id'] == $UserData['User']['id']){
//                              
//                          }else{
//                                $ToEmail = $this->decrypt($userDataEmail['User']['email']);
//                                $username = $this->decrypt($userDataEmail['User']['username']).' '.$this->decrypt($userDataEmail['User']['surname']);
//                                $params = array('to' => $ToEmail, 'Firstname' => $username, 'user_id' => $userDataEmail['User']['id']);
//                                $haystack = array('[UserName]','[GroupName]' ,'[GroupAdminName]','[ChallengeName]','[DOMAIN_NAME]');
//                                $replace = array($username,$GroupName,$AdminName,$challengeName, BASEURL);
//                                $this->SendEmail('group_challenge_invitation', $params, $haystack, $replace);  // email notification
//                          }
                      
                        
                        
                        if($userDataEmail['User']['platform'] == 'Android'){
                          if($userDataEmail['User']['id'] == $UserData['User']['id']){
                              
                          }else{
                              $this->requestAction('/Push/push_android/' . $userDataEmail['User']['id'].'/'.$AdminName.'/'.$GroupName.'/'.$groupId.'/'.$Challenge_id);
                          }
                          
                     }else{
                              $ArrToSend['userId'] = $userDataEmail['User']['id'];
                              $ArrToSend['adminName'] = $AdminName;
                              $ArrToSend['groupName'] = $GroupName;
                              $ArrToSend['groupId'] = $groupId;
                              $ArrToSend['challengeId'] = $Challenge_id;
                              $ArrToSend['flag'] = 'create_group_challenge';
                              $ArrToSend['message'] = 'You have received a challenge invitation from '.$GroupName.'. Touch for details';
                              //$this->requestAction('/Push/send_push_notification/'. $ArrToSend);
                              $this->requestAction(
                            array('controller' => 'Push', 'action' => 'send_push_notification'),
                                array('pass' => $ArrToSend)
                                    );
                          }
                   

                }
                 } // for end
                 if(!empty($Emails)){
                     $data['nameForEmail'] = decrypt($userEmailData['User']['username']).' '.decrypt($userEmailData['User']['surname']);
                 }else{
                     $data['nameForEmail'] = '';
                 }
                  $data['status'] = '1';
                    $data['message'] = 'group created successfully';
                    echo json_encode($data);
            } else {
                $data['status'] = '0';
                $data['message'] = 'group creation fail';
                echo json_encode($data);
            }
        } else {
            $data['status'] = '0';
            $data['message'] = 'group creation fail';
            echo json_encode($data);
        }
    }
    
    public function createGroupChallengeForCreatedGroup() {

        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        $this->loadModel('GroupMember');
        if ($this->request->is('post')) {
            $userId = $this->request->data['userId'];
            $challengeId = $this->request->data['challengeId'];
            $groupIds = $this->request->data['groupIds'];
            $Duration = $this->request->data['time_limit'];
            $endMoves = $this->request->data['endMoves'];
            $challenge_type = $this->request->data['challenge_type'];
            $group_challenge_type = $this->request->data['group_challenge_type'];
            $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $userId)));
            $AdminName = $this->decrypt($UserData['User']['username']).' '.$this->decrypt($UserData['User']['surname']); 
            $challengeDetails = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $challengeId)));
            $challengeName = $challengeDetails['Challenge']['challenges_name'];
           // $IdArr = explode(",", $groupIds);
                 for ($i = 0; $i < sizeof($groupIds); $i++) {
//                    $MembersData[] = $this->GroupMember->find('all', array('conditions' => array('GroupMember.groups_id' => $groupIds[$i],'GroupMember.status'=>1)));
                    $dataTosave['status'] = 1;
                     $this->Group->id = $groupIds[$i];
                     $this->Group->save($dataTosave);
                     $MembersData[] = $this->GroupMember->find('all', array('conditions' => array('GroupMember.groups_id' => $groupIds[$i])));
                 }
                 
                 if(!empty($MembersData)){
                     
                     foreach ($MembersData as $key => $value) {
                         foreach ($value as $key => $Newvalue) {
                             $groupChallengeData['user_id'] = $Newvalue['GroupMember']['user_id'];
                             $groupChallengeData['groups_id'] = $Newvalue['GroupMember']['groups_id'];
                             $groupChallengeData['challenges_id'] = $challengeId;
                             $groupChallengeData['end_moves'] = $endMoves;
                             $groupChallengeData['challenge_type'] = $challenge_type;
                             $groupChallengeData['group_challenge_type'] = $group_challenge_type;
                             $groupChallengeData['status'] = 3;  
                             $this->GroupChallenge->create();
                             if($this->GroupChallenge->save($groupChallengeData)){
                                 $groupChallengesId = $this->GroupChallenge->getLastInsertID();
                                 
                                 $groupChallengeInvitesData['groups_id'] = $Newvalue['GroupMember']['groups_id'];
                                 $groupChallengeInvitesData['challenges_id'] = $challengeId;
                                 $groupChallengeInvitesData['group_challenges_id'] = $groupChallengesId;
                                 $groupChallengeInvitesData['user_id'] = $Newvalue['GroupMember']['user_id'];
                                 
                                 if ($Newvalue['GroupMember']['user_id'] == $UserData['User']['id']) {
                                    $groupChallengeInvitesData['status'] = 1;
                                }else{
                                    $groupChallengeInvitesData['status'] = 2;
                                }
                                 
                                
                                 $groupChallengeInvitesData['invitation_sent_on'] = date('Y-m-d H:i:s');
                                  $this->GroupChallengeInvite->create();
                                 if($this->GroupChallengeInvite->save($groupChallengeInvitesData)){
                                     
                                    // code to send email and notification
                                        $userDataEmail = $this->User->find('first', array('conditions' => array('User.id' => $Newvalue['GroupMember']['user_id'])));
                                        
                                          if($userDataEmail['User']['id'] == $UserData['User']['id']){

                                                    }else{
                                                         $ToEmail = $this->decrypt($userDataEmail['User']['email']);
                                                        $username = $this->decrypt($userDataEmail['User']['username']).' '.$this->decrypt($userDataEmail['User']['surname']);
                                                        $USERNAME[] =  $username;
                                                        $groupData = $this->Group->find('first', array('conditions' => array('Group.groups_id' =>$Newvalue['GroupMember']['groups_id'])));  
                                                        $GroupName = $groupData['Group']['groupname'];
                                                        $params = array('to' => $ToEmail, 'Firstname' => $username, 'user_id' => $userDataEmail['User']['id']);
                                                        $haystack = array('[UserName]','[GroupName]' ,'[GroupAdminName]','[ChallengeName]','[DOMAIN_NAME]');
                                                        $replace = array($username,$GroupName,$AdminName,$challengeName, BASEURL);
                                                       // $this->SendEmail('group_challenge_invitation', $params, $haystack, $replace);  // email notification
                                                    }
                                        
                                       
                                        
                                        // push notification
                                             if($userDataEmail['User']['platform'] == 'Android'){
                                                    if($userDataEmail['User']['id'] == $UserData['User']['id']){

                                                    }else{
                                                        $this->requestAction('/Push/push_android/' . $userDataEmail['User']['id'].'/'.$AdminName.'/'.$GroupName.'/'.$Newvalue['GroupMember']['groups_id'].'/'.$challengeId);
                                                    }

                                           }else{
                                                    $ArrToSend['userId'] = $userDataEmail['User']['id'];
                                                    $ArrToSend['adminName'] = $AdminName;
                                                    $ArrToSend['groupName'] = $GroupName;
                                                    $ArrToSend['groupId'] = $Newvalue['GroupMember']['groups_id'];
                                                    $ArrToSend['challengeId'] = $challengeId;
                                                    $ArrToSend['flag'] = 'create_group_challenge';
                                                    $ArrToSend['message'] = 'You have received a challenge invitation from '.$GroupName.'. Touch for details';
                                                    //$this->requestAction('/Push/send_push_notification/'. $ArrToSend);
                                                    $this->requestAction(
                                                    array('controller' => 'Push', 'action' => 'send_push_notification'),
                                                      array('pass' => $ArrToSend)
                                                          );
                                                }
                                        //push notification end        
                                 }
                             }
                         }
                     }
                     $data['status'] = '1';
                     $data['username'] = $USERNAME;
                    $data['message'] = 'group created successfully';
                    echo json_encode($data);
                 }else{
                      $data['status'] = '0';
                    $data['message'] = 'error';
                    echo json_encode($data);
                 }
        }
    }

    public function CreateGroup() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        $this->loadModel('GroupMember');

        $Userid = $this->request->data['userId'];
        $Membersid = $this->request->data['members_id'];
        $GroupName = $this->request->data['group_name'];
        
       
        $Emails = $this->request->data['email'];
        if(!empty($Emails)){
          $EmailArr = explode(",", $Emails);
                for ($i = 0; $i < sizeof($EmailArr); $i++) {
                    $userEmailData = $this->User->find('first', array('conditions' => array('User.email' => $EmailArr[$i])));
                        if(!empty($userEmailData)){
                           $Membersid = $Membersid.','.$userEmailData['User']['id'];
                        }
                }  
        }
        
       

        $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $Userid)));
        $AdminName = $this->decrypt($UserData['User']['username']).' '.$this->decrypt($UserData['User']['surname']);
        $data['user_id'] = $UserData['User']['id'];
        $data['groupname'] = $GroupName;
        $data['status'] = 0;

        if ($this->request->is('post')) {
            if ($this->Group->save($data)) {

                $groupId = $this->Group->getLastInsertID();

                $IdArr = explode(",", $Membersid);
                for ($i = 0; $i < sizeof($IdArr); $i++) {
                    $groupMembersData['groups_id'] = $groupId;
                    $groupMembersData['user_id'] = $IdArr[$i];  
                    if ($IdArr[$i] == $UserData['User']['id']) {
                        $groupMembersData['status'] = 1;
                    } else {
                        $groupMembersData['status'] = 2;
                    }
                    $this->GroupMember->create();
                    $this->GroupMember->save($groupMembersData);
                    $userDataEmail = $this->User->find('first', array('conditions' => array('User.id' => $IdArr[$i])));
                    
//                      if($userDataEmail['User']['id'] == $UserData['User']['id']){
//                              
//                          }else{
//                               $ToEmail = $this->decrypt($userDataEmail['User']['email']);
//                                $username = $this->decrypt($userDataEmail['User']['username']).' '.$this->decrypt($userDataEmail['User']['surname']);
//                                $params = array('to' => $ToEmail, 'Firstname' => $username, 'user_id' => $userDataEmail['User']['id']);
//                                $haystack = array('[UserName]','[GroupName]' ,'[GroupAdminName]','[DOMAIN_NAME]');
//                                $replace = array($username,$GroupName,$AdminName, BASEURL);
//                                $this->SendEmail('group_invitation', $params, $haystack, $replace);  // email notification
//                          }
                   
                    
                    
                     if($userDataEmail['User']['platform'] == 'Android'){
                          if($userDataEmail['User']['id'] == $UserData['User']['id']){
                              
                          }else{
                              $this->requestAction('/Push/push_android/' . $userDataEmail['User']['id'].'/'.$AdminName.'/'.$GroupName.'/'.$groupId);
                          }
                          
                     }else{
                         if($userDataEmail['User']['id'] == $UserData['User']['id']){
                              
                          }else{
                              $ArrToSend['userId'] = $userDataEmail['User']['id'];
                              $ArrToSend['adminName'] = $AdminName;
                              $ArrToSend['groupName'] = $GroupName;
                              $ArrToSend['groupId'] = $groupId;
                              $ArrToSend['flag'] = 'create_group';
                              $ArrToSend['message'] = 'You have been invited to join the '.$GroupName.' group created by '.$AdminName.'. Touch for details';
                              //$this->requestAction('/Push/send_push_notification/'. $ArrToSend);
                              $this->requestAction(
                            array('controller' => 'Push', 'action' => 'send_push_notification'),
                                array('pass' => $ArrToSend)
                                    );
                          }
                     }
                }
                
                $data['status'] = '1';
                $data['message'] = 'group created successfully';
                echo json_encode($data);
            } else {
                $data['status'] = '0';
                $data['message'] = 'group creation fail';
                echo json_encode($data);
            }
        } else {
            $data['status'] = '0';
            $data['message'] = 'group creation fail';
            echo json_encode($data);
        }
    }
    
    public function checkGroupsPendingNotification() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('GroupMember');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        if ($this->request->is('post')) {
            $user_id = $this->request->data['userId'];
            $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $user_id)));
            $userPendingInfo =  $this->GroupMember->find('all', array('conditions' => array('GroupMember.user_id' => $UserData['User']['id'],'GroupMember.status'=>2)));
            
            if(!empty($userPendingInfo)){
                
                $expiredDate = date('Y-m-d H:i:s', strtotime($userPendingInfo['GroupMember']['invitation_sent_on']. "+24 hour"));
                $currentDateTime = date('Y-m-d H:i:s'); 
                
                if($expiredDate >= $currentDateTime){
                   foreach ($userPendingInfo as $key => $value) {
                    $groupdata = $this->Group->find('first', array('conditions' => array('Group.groups_id' => $value['GroupMember']['groups_id'])));
                    $admindata = $this->User->find('first', array('conditions' => array('User.id' => $groupdata['Group']['user_id'])));
                    $data[$key]['status'] = '1';
                    $data[$key]['groupId'] = $groupdata['Group']['groups_id'];
                    $data[$key]['groupName'] = $groupdata['Group']['groupname'];
                    $data[$key]['AdminName'] = $this->decrypt($admindata['User']['username']).' '.$this->decrypt($admindata['User']['surname']);
                }
                  $data1['status'] = '1';   
                  $data1['response'] = $data;   
                 echo json_encode($data1); 
                    
                }else{
                $data['status'] = '0';
                echo json_encode($data);
            }
                
            }else{
                $data['status'] = '0';
                echo json_encode($data);
            }
        }
    }
    public function checkGroupsChallengePendingNotification() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('GroupMember');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        if ($this->request->is('post')) {
            $user_id = $this->request->data['userId'];
            $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $user_id)));
            $userPendingInfo =  $this->GroupChallengeInvite->find('first', array('conditions' => array('GroupChallengeInvite.user_id' => $UserData['User']['id'],'GroupChallengeInvite.status'=>2),'order'=>array('GroupChallengeInvite.group_challenge_invites_id DESC')));
            if(!empty($userPendingInfo)){
                
                $expiredDate = date('Y-m-d H:i:s', strtotime($userPendingInfo['GroupChallengeInvite']['invitation_sent_on']. "+24 hour"));
                $currentDateTime = date('Y-m-d H:i:s'); 
                
                if($expiredDate >= $currentDateTime){
                  //   foreach ($userPendingInfo as $key => $value) {
                         
                    $groupdata = $this->Group->find('first', array('conditions' => array('Group.groups_id' => $userPendingInfo['GroupChallengeInvite']['groups_id'])));
                    $data[0]['status'] = '1';
                    $data[0]['challengeId'] = $userPendingInfo['GroupChallengeInvite']['challenges_id'];
                    $data[0]['groupId'] = $groupdata['Group']['groups_id'];
                    $data[0]['groupName'] = $groupdata['Group']['groupname'];
                   
               // }
                  $data1['status'] = '1';   
                  $data1['response'] = $data;   
                 echo json_encode($data1);
                }else{
                $data['status'] = '0';
                echo json_encode($data);
                
                }
               
            }else{
                $data['status'] = '0';
                echo json_encode($data);
            }
        }
    }
    
    

    public function getUserGroups() {

        
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('GroupMember');
        if ($this->request->is('post')) {
            $user_id = $this->request->data['userId'];
            $group_id_Str = '';
            $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $user_id)));

            $grpIds = $this->GroupMember->find('all', array('fields' => array('GroupMember.groups_id'),'conditions' => array('GroupMember.user_id' => $UserData['User']['id'],'GroupMember.status'=>'1'))); 
            
            
            foreach ($grpIds as $grp) {
                //$userGroups[$key] = $this->Group->find('first', array('conditions' => array('Group.groups_id' => $value['GroupMember']['groups_id'],'Group.status IN (0,1,2)')));
                $group_id_Str .= $grp['GroupMember']['groups_id'].',';
            }
            $group_id_Str = rtrim($group_id_Str,',');
            
            $userGroups = $this->Group->find('all', array('conditions' => array("Group.groups_id IN ({$group_id_Str})",'Group.status IN (0,1,2)')));


            if (!empty($userGroups)) {
                $data['status'] = '1';
                $data['userGroups'] = $userGroups;
                echo json_encode($data);
            } else {
                $data['status'] = '2';
                $data['message'] = 'user have no groups';

                echo json_encode($data);
            }
        } else {
            $data['status'] = '0';
            $data['message'] = 'unauthorised';

            echo json_encode($data);
        }
    }
    public function getMyUserGroups() {


        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupMember');
        if ($this->request->is('post')) {
            $user_id = $this->request->data['userId'];

            $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $user_id)));

            $groupStr = '';
                $userGroups = $this->Group->find('all', array('conditions' => array('Group.user_id' => $UserData['User']['id'],'Group.status'=>0)));
                
                foreach($userGroups as $groupsAvailable)
                {
                    $groupChIDs = $this->GroupChallenge->find('all', array('fields' => 'GroupChallenge.groups_id', 'conditions' => array('GroupChallenge.groups_id' => $groupsAvailable['Group']['groups_id'], 'GroupChallenge.status' => 1)));
                    @$grpIds[] = $groupChIDs['GroupChallenge']['groups_id'];
                }
                
                $groupStr = implode(',', $grpIds);
           
                $AvailableuserGroups = $this->Group->find('all', array('conditions' => array('NOT' =>array('Group.groups_id' => $groupStr), 'Group.user_id' => $UserData['User']['id'],'Group.status'=>0)));

            if (!empty($AvailableuserGroups)) {
                $data['status'] = '1';
                $data['userGroups'] = $AvailableuserGroups;
                echo json_encode($data);
            } else {
                $data['status'] = '2';
                $data['message'] = 'user have no groups';

                echo json_encode($data);
            }
        } else {
            $data['status'] = '0';
            $data['message'] = 'unauthorised';

            echo json_encode($data);
        }
    }

    

    public function getGroupMembersName() {

        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('GroupChallengeInvite');
        if ($this->request->is('post')) {
            $GroupIds = $this->request->data['groupIds'];
            $IdArr = explode(",", $GroupIds);
            for ($i = 0; $i < sizeof($IdArr); $i++) {
                $UserIds[] = $this->GroupChallengeInvite->find('all', array(
                    'conditions' => array('GroupChallengeInvite.groups_id' => $IdArr[$i]),
                    'fields' => array('GroupChallengeInvite.user_id')));
            }
            print_r($UserIds);
        }
    }

    public function getUserId() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('GroupChallengeInvite');
        if ($this->request->is('post')) {
            $userId = $this->request->data['userId'];
            $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $userId)));
            if (!empty($UserData)) {
                echo $UserData['User']['id'];
            } else {
                echo '0';
            }
        }
    }

    public function getMemberName() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('GroupMember');
        if ($this->request->is('post')) {
            $groupId = $this->request->data['groupId'];
            $groupMembersDetails = $this->GroupMember->find('all', array('conditions' => array('GroupMember.groups_id' => $groupId, 'GroupMember.status !=' => 9)));
            if (!empty($groupMembersDetails)) {
                foreach ($groupMembersDetails as $key => $value) {
                    $userName[] = $this->User->find('first', array(
                        'conditions' => array('User.id' => $value['GroupMember']['user_id']),
                        'fields' => array('User.username','User.surname', 'User.id','User.profile_photo')));
                    $userName[$key]['User'][] = $value['GroupMember']['status'];
                }

                if (!empty($userName)) {
                    foreach ($userName as $key => $value) {
                        if($value['User']['surname'] == null){
                            $surname = '';
                        }else{
                            $surname = $this->decrypt($value['User']['surname']);
                        }
                        $data[$key]['username'] = $this->decrypt($value['User']['username']).' '.$surname;
                        $data[$key]['status'] = $value['User']['0'];
                        $data[$key]['id'] = $value['User']['id'];
                        $data[$key]['photo'] = $value['User']['profile_photo'];
                    }
                    return json_encode($data);
                } else {
                    $data = '0';
                    return json_encode($data);
                }
            } else {
                $data = '0';
                return json_encode($data);
            }
        }
    }

    public function getChallengesDetails() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallengeInvite');
        $this->loadModel('GroupChallenge');
        if ($this->request->is('post')) {
            $userId = $this->request->data['userId'];
            $groupId = $this->request->data['groupId'];

            $challengesIds = $this->GroupChallenge->find('all', array(
                'conditions' => array('GroupChallenge.groups_id' => $groupId, 'GroupChallenge.user_id' => $userId, 'GroupChallenge.status IN (0,3)'),
                'fields' => array('GroupChallenge.challenges_id','GroupChallenge.status')));
            if (!empty($challengesIds)) {

                foreach ($challengesIds as $key => $value) {
                        $challengesDetails[] = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $value['GroupChallenge']['challenges_id'])));
                        $challengesDetails[$key]['status'] = $value['GroupChallenge']['status'];
                }
                
                return json_encode($challengesDetails);
            } else {
                $data = '0';
                return json_encode($data);
            }
        }
    }

    public function getGroupChallengesDetails() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallenge');
        if ($this->request->is('post')) {
            $user_id = $this->request->data['userId'];
           // $GroupID = $this->request->data['grpId'];

            $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $user_id)));

//            $userGroups = $this->Group->find('all', array('conditions' => array('Group.user_id' => $UserData['User']['id'])));
//            $GroupID = array();
//            foreach ($userGroups as $group) {
//                $GroupID[] = $group['Group']['groups_id'];
//            }
            $challengesIds = $this->GroupChallenge->find('all', array(
                'conditions' => array(/*'GroupChallenge.groups_id' => $GroupID,*/'GroupChallenge.user_id'=>$UserData['User']['id'], 'GroupChallenge.status IN (0,1,4)'),
                'joins' => array(
                    array(
                        'table' => 'challenges',
                        'alias' => 'Challenge',
                        'type' => 'INNER',
                        'foreignKey' => false,
                        'conditions' => array('GroupChallenge.challenges_id=Challenge.challenges_id')
                    ), array(
                        'table' => 'groups',
                        'alias' => 'Group',
                        'type' => 'INNER',
                        'foreignKey' => false,
                        'conditions' => array('GroupChallenge.groups_id=Group.groups_id')
                    )),
                'fields' => array('Group.user_id','GroupChallenge.groups_id','GroupChallenge.challenges_id', 'GroupChallenge.status', 'Challenge.challenges_name', 'Challenge.trophy','Challenge.trophy_base64','Challenge.banner','Challenge.banner_base64','Challenge.moves_reward','Challenge.time_limit'),
                'order' => 'GroupChallenge.challenges_id DESC'));
            //print_r($challengesIds);exit;
            if (!empty($challengesIds)) {
                return json_encode($challengesIds);
            } else {
                $data = '0';
                return json_encode($data);
            }
        }
    }

    public function leaveChallenge() {

        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        if ($this->request->is('post')) {
            $UserId = $this->request->data['userId'];
            $groupId = $this->request->data['grpId'];
            $challengeId = $this->request->data['challengeId'];
            
            $userdata = $this->GroupChallengeInvite->find('first', array(
                'conditions' => array('GroupChallengeInvite.groups_id' => $groupId, 'GroupChallengeInvite.user_id' => $UserId, 'GroupChallengeInvite.challenges_id' => $challengeId)));
            
            $GroupchallengeDetails = $this->GroupChallenge->find('first', array(
                'conditions' => array('GroupChallenge.groups_id' => $groupId, 'GroupChallenge.user_id' => $UserId, 'GroupChallenge.challenges_id' => $challengeId)));
            
            if(!empty($GroupchallengeDetails)){
                $Tosave['status'] = 2;
                $this->GroupChallenge->id = $GroupchallengeDetails['GroupChallenge']['group_challenges_id'];
                $this->GroupChallenge->save($Tosave);
            }
            
            
            if (!empty($userdata)) {
                $savedData['status'] = 0;
                $this->GroupChallengeInvite->id = $userdata['GroupChallengeInvite']['group_challenge_invites_id'];
                if ($this->GroupChallengeInvite->save($savedData)) {
                    
                    // if after leaving challenge only one user remains then cancel that challenge
                    $NoOfValidUser = $this->GroupChallengeInvite->find('all', array(
                'conditions' => array('GroupChallengeInvite.groups_id' => $groupId,'GroupChallengeInvite.challenges_id' => $challengeId,'GroupChallengeInvite.status'=>1)));
                    $number = count($NoOfValidUser);
                    
                    if($number <= 1){
                        foreach ($NoOfValidUser as $value) {
                            $savedData['status'] = 0;
                            $this->GroupChallengeInvite->id = $value['GroupChallengeInvite']['group_challenge_invites_id'];
                            $this->GroupChallengeInvite->save($savedData);
                        }
                        
                         $GroupchallengeDetails = $this->GroupChallenge->find('all', array(
                'conditions' => array('GroupChallenge.groups_id' => $groupId, 'GroupChallenge.challenges_id' => $challengeId)));
                        
                        foreach ($GroupchallengeDetails as $value) {
                            $Tosave['status'] = 2;
                            $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                            $this->GroupChallenge->save($Tosave);
                        }
                        
                        // group will be available now for further use
                        $Tosave['status'] = 0;
                            $this->Group->id = $groupId;
                            $this->Group->save($Tosave);
                        
                    }
                    // end here
                    
                    
                    $data['status'] = '1';
                    return json_encode($data);
                } else {
                    $data['status'] = '0';
                    return json_encode($data);
                }
            } else {
                $data['status'] = '0';
                return json_encode($data);
            }
        }
    }

    public function removeMember() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        $this->loadModel('GroupMember');
        if ($this->request->is('post')) {
            $UserId = $this->request->data['userId'];
            $groupId = $this->request->data['grpId'];
            $UserDetails = $this->User->find('first', array('conditions' => array('User.id' => $UserId)));
            $userdata = $this->GroupMember->find('first', array(
                'conditions' => array('GroupMember.groups_id' => $groupId, 'GroupMember.user_id' => $UserId)));
            $userdataInvite = $this->GroupChallengeInvite->find('first', array(
                'conditions' => array('GroupChallengeInvite.groups_id' => $groupId, 'GroupChallengeInvite.user_id' => $UserId)));
            if (!empty($userdata)) {
                $savedData['status'] = 9;
                $this->GroupMember->id = $userdata['GroupMember']['group_members_id'];
               
                if ($this->GroupMember->save($savedData)) {
                    
                    if(!empty($userdataInvite)){
                        $this->GroupChallengeInvite->id = $userdataInvite['GroupChallengeInvite']['group_challenge_invites_id'];
                        $savedData['status'] = 0;
                        $this->GroupChallengeInvite->save($savedData);
                    }
                    
                    // check for wether valid users are less than 2, if yes delete group and challenge
                    
                    $groupMembersData =  $this->GroupMember->find('all', array(
                                         'conditions' => array('GroupMember.groups_id' => $groupId, 'GroupMember.status' => 1)));
                    
                    $No_of_valid_users = count($groupMembersData);
                    
                    if($No_of_valid_users <= 1){
                        foreach ($groupMembersData as $key => $value) {
                            $data['status'] = 9;
                             $this->GroupMember->id = $value['GroupMember']['group_members_id'];
                             $this->GroupMember->save($data);
                               $userdataInvite1 = $this->GroupChallengeInvite->find('first', array(
                                'conditions' => array('GroupChallengeInvite.groups_id' => $groupId)));
                                $this->GroupChallengeInvite->id = $userdataInvite1['GroupChallengeInvite']['group_challenge_invites_id'];
                        $savedData['status'] = 0;
                        $this->GroupChallengeInvite->save($savedData);
                        }  
                    }else{
                        
                    }
                    
                    
                    
                    $data['status'] = '1';
                    return json_encode($data);
                } else {
                    $data['status'] = '0';
                    return json_encode($data);
                }
            } else {
                $data['status'] = '0';
                return json_encode($data);
            }
        }
    }
    
    public function getChallengeUpdate() {
        //Configure::write('debug', 2);
         $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        $this->loadModel('GroupMember');
        if ($this->request->is('post')) {
            $challengeID = $this->request->data['challengeId'];
            $groupId = $this->request->data['grpId'];
            
            $validUsers = $this->GroupChallengeInvite->find('all', array(
                'conditions' => array('GroupChallengeInvite.groups_id' => $groupId, 'GroupChallengeInvite.challenges_id' => $challengeID,'GroupChallengeInvite.status'=>array(1,2))));
            
           
            $challengesData = $this->GroupChallenge->find('all', array(
                'conditions' => array('GroupChallenge.groups_id' => $groupId, 'GroupChallenge.challenges_id' => $challengeID),
                'order'=>array('GroupChallenge.moves_to_date DESC')));
            if(!empty($challengesData)){
              foreach ($validUsers as $key1 => $value1) {  
                foreach ($challengesData as $key => $value) {
  
                    if($value['GroupChallenge']['user_id']==$value1['GroupChallengeInvite']['user_id']){
                      // echo "1";
                        $UserData[] = $this->User->find('first', array(
                         'conditions' => array('User.id' => $value['GroupChallenge']['user_id']),
                         'fields' =>array('User.username','User.surname','User.profile_photo')));
                     $UserData[$key1]['end_moves'] = $value['GroupChallenge']['end_moves'];
                     $UserData[$key1]['moves_to_date'] = $value['GroupChallenge']['moves_to_date'];
                    }
                    
                }
              } 
              //print_r($UserData);die;
                foreach ($UserData as $key => $value) {
                        $UserData[$key]['username'] = $this->decrypt($value['User']['username']).' '.$this->decrypt($value['User']['surname']);
                        $UserData[$key]['photo'] = $value['User']['profile_photo'];
                    }
                    
                 $data = $this->GroupChallenge->find('first', array(
                'conditions' => array('GroupChallenge.groups_id' => $groupId, 'GroupChallenge.challenges_id' => $challengeID)));   
                
//            print_r($data);
                 if($data['GroupChallenge']['start_timestamp'] == '0000-00-00 00:00:00' || $data['GroupChallenge']['start_timestamp'] == '' || $data['GroupChallenge']['start_timestamp'] == null || $data['GroupChallenge']['start_timestamp'] == 'undefined'){
                     $UserData[0]['start_time'] = 'TBC';
                 }else{
                     $UserData[0]['start_time'] = date("d M y H:i", strtotime($data['GroupChallenge']['start_timestamp']));
                     //$UserData[0]['start_time'] = 'TBC';
                 }
                 
                 
                 if($data['GroupChallenge']['end_timestamp'] == '' || $data['GroupChallenge']['end_timestamp'] == null || $data['GroupChallenge']['end_timestamp'] == 'undefined'){
                     $UserData[0]['end_time'] = 'TBC';
                 }else if($data['GroupChallenge']['end_timestamp'] == '0000-00-00 00:00:00'){
                      $UserData[0]['end_time'] = 'N/A';
                 }else{
                     $UserData[0]['end_time'] = date("d M y H:i", strtotime($data['GroupChallenge']['end_timestamp']));
                 }
                
                 $today = date('Y-m-d H:i:s');
                 if($data['GroupChallenge']['end_timestamp'] != '0000-00-00 00:00:00'){
                     if($data['GroupChallenge']['end_timestamp'] <= $today && $data['GroupChallenge']['status'] == 0){
                        $UserData[0]['showDiv'] = '1'; 
                     }else{
                         $UserData[0]['showDiv'] = '0';
                     }
                 }else{
                     $UserData[0]['showDiv'] = '0';
                 }
                
                return json_encode($UserData);
            }else{
                $UserData = '0';
                 return json_encode($UserData);
            }
        }
    }
    public function getChallengeUpdateNew() {
        Configure::write('debug', 0);
         $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        $this->loadModel('GroupMember');
        if ($this->request->is('post')) {
            $challengeID = $this->request->data['challengeId'];
            $groupId = $this->request->data['grpId'];
            
             $validUsers = $this->GroupChallengeInvite->find('all', array(
                'conditions' => array('GroupChallengeInvite.groups_id' => $groupId, 'GroupChallengeInvite.challenges_id' => $challengeID,'GroupChallengeInvite.status'=>array(1,2)),
                 'fields'=>array('GroupChallengeInvite.user_id')));
              
             $validUsers = Set::classicExtract($validUsers, '{n}.GroupChallengeInvite.user_id');
             
            foreach ($validUsers as $value) {
                $user_id_Str1 .= $value.',';
            }
            $validUserIds = rtrim($user_id_Str1,',');               
                      
            $this->GroupChallenge->bindModel(array(
                 'belongsTo' => array('User'=>array(
                        'className' => 'User',
                        'foreignKey' => false,
                        'conditions' => array(
                                'GroupChallenge.user_id = User.id'),
                        'fields'=>array('User.username','User.surname','User.profile_photo'))))); 
            
           $challengesData = $this->GroupChallenge->find('all', array(
                'conditions' => array('GroupChallenge.groups_id' => $groupId, 'GroupChallenge.challenges_id' => $challengeID,"GroupChallenge.user_id IN ({$validUserIds})"),
                'order'=>array('GroupChallenge.moves_to_date DESC')));
                
            foreach ($challengesData as $key => $value) {
               $challengesData[$key]['User']['username'] =  $this->decrypt($value['User']['username']);
               $challengesData[$key]['User']['surname'] = $this->decrypt($value['User']['surname']);
            }    
          // print_r($challengesData);
            return json_encode($challengesData);
        }
    }
    
    
    public function CancelChallenge() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        $this->loadModel('GroupMember');
        if ($this->request->is('post')) {
            $challengeID = $this->request->data['challengeId'];
            $groupId = $this->request->data['grpId'];
            $UserId = $this->request->data['userId'];
            
            $userData = $this->User->find('first', array('conditions' => array('User.user_id' => $UserId)));
            
            // group will be available for future use
            
            $saveData['status'] = 0;
                $this->Group->id = $groupId;
                $this->Group->save($saveData);
            //
            
             $ChallengeData = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $challengeID)));
            $challengeName = $ChallengeData['Challenge']['challenges_name'];
             
             $data = $this->GroupChallengeInvite->find('all', array(
                'conditions' => array('GroupChallengeInvite.groups_id' => $groupId, 'GroupChallengeInvite.challenges_id' => $challengeID,'GroupChallengeInvite.status'=>1)));  
            
            //print_r($data);
            if(!empty($data)){
                
            foreach ($data as $key => $value) {
                
                $saveData['status'] = 2;
                $this->GroupChallenge->id = $value['GroupChallengeInvite']['group_challenges_id'];
                $this->GroupChallenge->save($saveData);
                $saveData['status'] = 0;
                $this->GroupChallengeInvite->id = $value['GroupChallengeInvite']['group_challenge_invites_id'];
                $this->GroupChallengeInvite->save($saveData);
                
                
                
                
                 $userDataEmail = $this->User->find('first', array('conditions' => array('User.id' => $value['GroupChallengeInvite']['user_id'])));
                
                
                if($userDataEmail['User']['platform'] == 'Android'){
                          if($userDataEmail['User']['id'] == $userData['User']['id']){
                              
                          }else{
                              $this->requestAction('/Push/push_android_for_cancel/' . $userDataEmail['User']['id'].'/'.$challengeName);
                          }
                          
                     }else{
                         if($userDataEmail['User']['id'] == $userData['User']['id']){
                              
                          }else{
                               $ArrToSend['flag'] = 'cancel_challenge';
                              $ArrToSend['userId'] = $userDataEmail['User']['id'];
                              $ArrToSend['message'] = $challengeName.' is no longer active. Touch for details';
                              $ArrToSend['challengeName'] = $challengeName;
                              //$this->requestAction('/Push/send_push_notification/'. $ArrToSend);
                              $this->requestAction(
                            array('controller' => 'Push', 'action' => 'send_push_notification'),
                                array('pass' => $ArrToSend)
                                    );
                          }
                     }
            }
            
            $response['status'] = '1';
            return json_encode($response);
                
            }else{
                $response['status'] = '0';
                    return json_encode($response); 
            }
        }
    }
    
    public function rejectGroupRequest() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        $this->loadModel('GroupMember');
        if ($this->request->is('post')) {
            $UserId = $this->request->data['userId'];
             $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $UserId)));
            $groupId = $this->request->data['grpId'];
              $userdata = $this->GroupMember->find('first', array(
                'conditions' => array('GroupMember.groups_id' => $groupId, 'GroupMember.user_id' => $UserData['User']['id'])));
            $this->GroupMember->id = $userdata['GroupMember']['group_members_id'];
            $data['status'] = 0;
            if($this->GroupMember->save($data)){
                
                
                $userdataForInvites = $this->GroupChallengeInvite->find('first', array(
                'conditions' => array('GroupChallengeInvite.groups_id' => $groupId, 'GroupChallengeInvite.user_id' => $UserData['User']['id'])));
                
                if(!empty($userdataForInvites)){
                    $saveThis['status'] = 0;
                    $this->GroupChallengeInvite->id = $userdataForInvites['GroupChallengeInvite']['group_challenge_invites_id'];
                    $this->GroupChallengeInvite->save($saveThis);
                }
                
                 $groupMembersData =  $this->GroupMember->find('all', array(
                                         'conditions' => array('GroupMember.groups_id' => $groupId, 'GroupMember.status' => array(1,2))));
                    
                    $No_of_valid_users = count($groupMembersData);
                    
                    if($No_of_valid_users <= 1){
                        foreach ($groupMembersData as $key => $value) {
                            $data['status'] = 0;
                             $this->GroupMember->id = $value['GroupMember']['group_members_id'];
                             $this->GroupMember->save($data);
                              
                        }  
                      // group is also removed in this case
                        $this->Group->id = $groupId;
                        $saveD['status'] = 9;
                        $this->Group->save($saveD);
                    }else{
                        
                    }
                
                
                $response['status'] = '1';
                  return json_encode($response);
            }else{
                $response['status'] = '0';
                  return json_encode($response);
            }
        }
    }
    public function acceptGroupRequest() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        $this->loadModel('GroupMember');
        if ($this->request->is('post')) {
            $UserId = $this->request->data['userId'];
             $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $UserId)));
            $groupId = $this->request->data['grpId'];
              $userdata = $this->GroupMember->find('first', array(
                'conditions' => array('GroupMember.groups_id' => $groupId, 'GroupMember.user_id' => $UserData['User']['id'])));
            $this->GroupMember->id = $userdata['GroupMember']['group_members_id'];
            $data['status'] = 1;
            if($this->GroupMember->save($data)){
                $response['status'] = '1';
                  return json_encode($response);
            }else{
                $response['status'] = '0';
                  return json_encode($response);
            }
        }
    }
    
    public function getChallengeName() {
         $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Challenge');
        if ($this->request->is('post')) {
            $ChallengeId = $this->request->data['challengeId'];
            $ChallengeData = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $ChallengeId)));
            if(!empty($ChallengeData)){
                return json_encode($ChallengeData);
            }else{
                $ChallengeData = '0';
                return json_encode($ChallengeData);
            }
        }
    }
    
    public function acceptGroupChallengeRequest() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        $this->loadModel('GroupMember');
        if ($this->request->is('post')) {
            $UserId = $this->request->data['userId'];
            $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $UserId)));
            $username = $this->decrypt($UserData['User']['username']).' '.$this->decrypt($UserData['User']['surname']);
            $groupId = $this->request->data['grpId'];
            $challengeId = $this->request->data['challengeId'];
            
            
              $userdata = $this->GroupChallengeInvite->find('first', array(
                'conditions' => array('GroupChallengeInvite.groups_id' => $groupId, 'GroupChallengeInvite.challenges_id' => $challengeId,'GroupChallengeInvite.user_id' => $UserData['User']['id'])));
              $userdataMember = $this->GroupMember->find('first', array(
                'conditions' => array('GroupMember.groups_id' => $groupId,'GroupMember.user_id' => $UserData['User']['id'])));
              
              $this->GroupChallengeInvite->id = $userdata['GroupChallengeInvite']['group_challenge_invites_id'];
              $this->GroupMember->id = $userdataMember['GroupMember']['group_members_id'];
            $data['status'] = 1;
            if($this->GroupChallengeInvite->save($data)){
                $this->GroupMember->save($data); // auto accept group member request if challenge is accepted
                
                // Notification to admin 
                
                // email
                $AdminData = $this->Group->find('first',array('conditions'=>array('Group.groups_id'=>$groupId)));
                $userDataEmail = $this->User->find('first',array('conditions'=>array('User.id'=>$AdminData['Group']['user_id'])));
                $challengeDetails = $this->Challenge->find('first',array('conditions'=>array('Challenge.challenges_id'=>$challengeId)));
                
                $ToEmail = $this->decrypt($userDataEmail['User']['email']);
                $AdminName = $this->decrypt($userDataEmail['User']['username']).' '.$this->decrypt($userDataEmail['User']['surname']);
                $params = array('to' => $ToEmail, 'Firstname' => $AdminName, 'user_id' => $userDataEmail['User']['id']);
                $haystack = array('[UserName]','[GroupName]' ,'[GroupAdminName]','[ChallengeName]','[DOMAIN_NAME]');
                $replace = array($username,$AdminData['Group']['groupname'],$AdminName,$challengeDetails['Challenge']['challenges_name'], BASEURL);
                $this->SendEmail('challenge_invitation_confirmation', $params, $haystack, $replace);  // email notification
                
                // push notification
                
                 if($userDataEmail['User']['platform'] == 'Android'){
                         $status = 'ForAndroidChallengeAcceptanceConfirmation';
                        $this->requestAction('/Push/push_android/' . $userDataEmail['User']['id'].'/'.$AdminName.'/'.$AdminData['Group']['groupname'].'/'.$groupId.'/'.$challengeId.'/'.$challengeDetails['Challenge']['challenges_name'].'/'.$status.'/'.$username);
                           
                     }else{
                              $ArrToSend['userId'] = $userDataEmail['User']['id'];
                              $ArrToSend['adminName'] = $AdminName;
                              $ArrToSend['groupName'] = $AdminData['Group']['groupname'];
                              $ArrToSend['groupId'] = $groupId;
                              $ArrToSend['UserName'] = $username;
                              $ArrToSend['challengeId'] = $challengeId;
                              $ArrToSend['challengeName'] = $challengeDetails['Challenge']['challenges_name'];
                              $ArrToSend['flag'] = 'accept_group_challenge';
                              $ArrToSend['message'] = 'Your invitation to join the group challenge '.$challengeDetails['Challenge']['challenges_name'].' for group '.$AdminData['Group']['groupname'].' is accepted by '.$username.'. Touch for details';
                              //$this->requestAction('/Push/send_push_notification/'. $ArrToSend);
                              $this->requestAction(
                            array('controller' => 'Push', 'action' => 'send_push_notification'),
                                array('pass' => $ArrToSend)
                                    );
                          }
                
                
                
                
                
                $response['status'] = '1';
                  return json_encode($response);
            }else{
                $response['status'] = '0';
                  return json_encode($response);
            }
        }
    }
    
    public function declineGroupChallengeRequest() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Group');
        $this->loadModel('Challenge');
        $this->loadModel('GroupChallenge');
        $this->loadModel('GroupChallengeInvite');
        $this->loadModel('GroupMember');
        if ($this->request->is('post')) {
            $UserId = $this->request->data['userId'];
            $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $UserId)));
            $groupId = $this->request->data['grpId'];
            $challengeId = $this->request->data['challengeId'];
            
            
             $GroupchallengeDetails = $this->GroupChallenge->find('first', array(
                'conditions' => array('GroupChallenge.groups_id' => $groupId, 'GroupChallenge.user_id' => $UserData['User']['id'], 'GroupChallenge.challenges_id' => $challengeId)));
            
            if(!empty($GroupchallengeDetails)){
                $Tosave['status'] = 2;
                $this->GroupChallenge->id = $GroupchallengeDetails['GroupChallenge']['group_challenges_id'];
                $this->GroupChallenge->save($Tosave); 
            }
            
            
              $userdata = $this->GroupChallengeInvite->find('first', array(
                'conditions' => array('GroupChallengeInvite.groups_id' => $groupId, 'GroupChallengeInvite.challenges_id' => $challengeId,'GroupChallengeInvite.user_id' => $UserData['User']['id'])));
               $userdataMember = $this->GroupMember->find('first', array(
                'conditions' => array('GroupMember.groups_id' => $groupId,'GroupMember.user_id' => $UserData['User']['id'])));
              
              $this->GroupChallengeInvite->id = $userdata['GroupChallengeInvite']['group_challenge_invites_id'];
              $this->GroupMember->id = $userdataMember['GroupMember']['group_members_id'];
            $data['status'] = 0;
            if($this->GroupChallengeInvite->save($data)){
                $dataTosave['status'] = '2';
                $this->GroupMember->save($dataTosave); // auto accept group member request if challenge is accepted
                
                
                 $groupMembersData =  $this->GroupMember->find('all', array(
                                         'conditions' => array('GroupMember.groups_id' => $groupId, 'GroupMember.status' => array(1,2))));
                    
                    $No_of_valid_users = count($groupMembersData);
                    
                    if($No_of_valid_users <= 1){
                        foreach ($groupMembersData as $key => $value) {
                            $data['status'] = 9;
                             $this->GroupMember->id = $value['GroupMember']['group_members_id'];
                             $this->GroupMember->save($data);
                               $userdataInvite1 = $this->GroupChallengeInvite->find('first', array(
                                'conditions' => array('GroupChallengeInvite.groups_id' => $groupId)));
                                $this->GroupChallengeInvite->id = $userdataInvite1['GroupChallengeInvite']['group_challenge_invites_id'];
                        $savedData['status'] = 9;
                        $this->GroupChallengeInvite->save($savedData);
                        }  
                    }else{
                        
                    }
                
                
                
                $response['status'] = '1';
                  return json_encode($response);
            }else{
                $response['status'] = '0';
                  return json_encode($response);
            }
        }
    }
    
    
     public function checkGroupChallengeCompleted($user_id)
        {
           //Configure::write('debug', 2);
            $this->autoRender = false;
            $this->layout = false;
            
            $this->loadModel('GroupChallenge');
            $this->loadModel('Challenge');
            $this->loadModel('CategoryChallenge');
            $this->loadModel('DailyMet');
            $this->loadModel('User');
            $this->loadModel('PointAward');
            $this->loadModel('Move');
                   
            $acceptedChallengeDetails = $this->GroupChallenge->find('all', array('conditions' => array('GroupChallenge.user_id' => $user_id, 'GroupChallenge.status' => 0), 'order' => 'GroupChallenge.group_challenges_id DESC'));
           
            if(!empty($acceptedChallengeDetails))
            {
                foreach ($acceptedChallengeDetails as $key => $value) 
                {
                    $challengeStartDate = $value['GroupChallenge']['start_timestamp'];
                    $challengeEndDate = $value['GroupChallenge']['end_timestamp'];
                    
                    if($challengeStartDate != '0000-00-00 00:00:00')
                    {
                    
                    if($value['GroupChallenge']['challenge_type'] == 1)
                    {
                        //$challengeStartDate = $value['GroupChallenge']['start_timestamp'];
                        //$challengeEndDate = $value['GroupChallenge']['end_timestamp'];
                        
                        
                        $challengesDetails = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $value['GroupChallenge']['challenges_id'])));
                        
                        // Get user total points from start date of challenge till this time if the challenge is still active
                        $totalPoints = $this->DailyMet->find('all', array('fields' => array('SUM(DailyMet.moves_earnt) AS points'), 'conditions' => array('DailyMet.daily_mets_timestamp >=' => strtotime($challengeStartDate), 'DailyMet.daily_mets_timestamp <=' => strtotime($challengeEndDate),'DailyMet.user_id' => $user_id)));
                        
                        
                        if($value['GroupChallenge']['group_challenge_type'] == 1 || $value['GroupChallenge']['group_challenge_type'] == 2)
                        {  // group challenge types Most ranking or Achievement based
                            if($totalPoints[0][0]['points'] >= $challengesDetails['Challenge']['moves_target'])
                            {
                                // If challenge is completed then change status of the challenge for that user
                                $completedChallengeData['moves_to_date'] = $totalPoints[0][0]['points'];
                                //$completedChallengeData['completed_date'] = date('Y-m-d H:i:s');
                                //$completedChallengeData['status'] = 1;

                                $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);
                                
                                
                                // IF challenge is Achievement based then update the status of challenge as completed if any one user reaches the goal
                                if($value['GroupChallenge']['group_challenge_type'] == 2)
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                    
                                }
                                
                                $returnArr = array('GroupChallengeCompleted' => '2', 'group_challenge_name' => $challengesDetails['Challenge']['challenges_name']);
                                return $returnArr;
                                
                            }else{

                                // If challenge is not completed then update the points of that user 
                                $completedChallengeData['moves_to_date'] = $totalPoints[0][0]['points'];
                                /*$this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);*/
                                
                                $this->GroupChallenge->query("UPDATE group_challenges SET moves_to_date = {$completedChallengeData['moves_to_date']} WHERE group_challenges_id = {$value['GroupChallenge']['group_challenges_id']} AND user_id = {$user_id}");
                                
                                $returnArr = array('GroupChallengeCompleted' => '0');
                                return $returnArr;
                            }
                        }elseif($value['GroupChallenge']['group_challenge_type'] == 3)
                        { // group challenge type collective efforts
                            if($totalPoints[0][0]['points'] >= $challengesDetails['Challenge']['moves_target'])
                            {
                                // If challenge is completed then change status of the challenge for that user
                                $completedChallengeData['moves_to_date'] = $totalPoints[0][0]['points'];
                                //$completedChallengeData['completed_date'] = date('Y-m-d H:i:s');
                                //$completedChallengeData['status'] = 1;

                                $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);
                                
                                
                                // check if the common goal of challenge is reached by this update. If yes then update the status of challenge for all group members participating in the challenge
                                $getAllMemData = $this->GroupChallenge->find('all', array('fields' => array('SUM(GroupChallenge.moves_to_date) AS TotMemPoints'),'conditions' => array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallenge.status' => 0)));
                                
                                $totMemPoints = $getAllMemData[0][0]['TotMemPoints'];
                                
                                if($totMemPoints >= $challengesDetails['Challenge']['moves_target'])
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                }
                                
                                
                                $returnArr = array('GroupChallengeCompleted' => '2', 'group_challenge_name' => $challengesDetails['Challenge']['challenges_name']);
                                return $returnArr;
                                
                            }else{
                                
                                $completedChallengeData['moves_to_date'] = $totalPoints[0][0]['points'];
                                $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);
                                
                                
                                // check if the common goal of challenge is reached by this update. If yes then update the status of challenge for all group members participating in the challenge
                                $getAllMemData = $this->GroupChallenge->find('all', array('fields' => array('SUM(GroupChallenge.moves_to_date) AS TotMemPoints'),'conditions' => array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallenge.status' => 0)));
                                
                                $totMemPoints = $getAllMemData[0][0]['TotMemPoints'];
                                
                                if($totMemPoints >= $challengesDetails['Challenge']['moves_target'])
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                    
                                }
                                
                                
                            }
                        }
                        
                    }                    
                    
                if($value['GroupChallenge']['challenge_type'] == '2') // 2 = calories challenge
                {
                    //$challengeStartDate = $value['GroupChallenge']['start_timestamp'];
                    //$challengeEndDate = $value['GroupChallenge']['end_timestamp'];


                    $challengesDetails = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $value['GroupChallenge']['challenges_id'])));
                        $totalCals = $this->DailyMet->find('all', array('fields' => array('SUM(DailyMet.calories) AS calories'), 'conditions' => array('DailyMet.daily_mets_timestamp >=' => strtotime($challengeStartDate), 'DailyMet.daily_mets_timestamp <=' => strtotime($challengeEndDate), 'DailyMet.user_id' => $user_id)));
                        
                    if($challengeEndDate == '0000-00-00 00:00:00')
                    {
                            //$totalCalories = $this->DailyMet->find('all', array('fields' => array('SUM(DailyMet.calories) AS tot_calories'), 'conditions' => array('DailyMet.daily_mets_timestamp >=' => strtotime($challengeStartDate), 'DailyMet.user_id' => $user_id)));

                            if($value['GroupChallenge']['group_challenge_type'] == 1 || $value['GroupChallenge']['group_challenge_type'] == 2)
                        { // group challenge types Most ranking or Achievement based
                            
                            
                            if($totalCals[0][0]['calories'] >= $challengesDetails['Challenge']['moves_target'])
                        {

                                // IF challenge is completed then update the status of the challenge 
                                $completedChallengeData['moves_to_date'] = $totalCals[0][0]['calories'];
                            //$completedChallengeData['completed_date'] = date('Y-m-d H:i:s');
                            //$completedChallengeData['status'] = 1;

                            $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                            $this->GroupChallenge->save($completedChallengeData);

                                // IF challenge is Achievement based then update the status of challenge as completed if any one user reaches the goal
                                if($value['GroupChallenge']['group_challenge_type'] == 2)
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                    
                                }
                           
                                
                                $returnArr = array('GroupChallengeCompleted' => '2', 'group_challenge_name' => $challengesDetails['Challenge']['challenges_name']);
                                return $returnArr;

                        }else{
                            
                            $moves_to_date =  $totalCals[0][0]['calories']; 
                            
                            /*$this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                            $this->GroupChallenge->saveField('moves_to_date', $moves_to_date);*/
                            $this->GroupChallenge->query("UPDATE group_challenges SET moves_to_date = {$moves_to_date} WHERE group_challenges_id = {$value['GroupChallenge']['group_challenges_id']} AND user_id = {$user_id}");
                            
                        }

                            
                        }elseif($value['GroupChallenge']['group_challenge_type'] == 3)
                        { // group challenge type collective efforts
                            if($totalCals[0][0]['calories'] >= $challengesDetails['Challenge']['moves_target'])
                            {
                                
                                // IF challenge is completed then update the status of the challenge 
                                $completedChallengeData['moves_to_date'] = $totalCals[0][0]['calories'];
                                //$completedChallengeData['completed_date'] = date('Y-m-d H:i:s');
                                //$completedChallengeData['status'] = 1;

                                $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);
                                
                                
                                // check if the common goal of challenge is reached by this update. If yes then update the status of challenge for all group members participating in the challenge
                                $getAllMemData = $this->GroupChallenge->find('all', array('fields' => array('SUM(GroupChallenge.moves_to_date) AS TotMemPoints'),'conditions' => array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallenge.status' => 0)));
                                
                                $totMemPoints = $getAllMemData[0][0]['TotMemPoints'];
                                
                                if($totMemPoints >= $challengesDetails['Challenge']['moves_target'])
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                    
                                }

                    
                                $returnArr = array('GroupChallengeCompleted' => '2', 'group_challenge_name' => $challengesDetails['Challenge']['challenges_name']);
                                return $returnArr;
                                

                            }else{
                                 
                                $moves_to_date =  $totalCals[0][0]['calories']; 

                                /*$this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->saveField('moves_to_date', $moves_to_date);*/
                                $this->GroupChallenge->query("UPDATE group_challenges SET moves_to_date = {$moves_to_date} WHERE group_challenges_id = {$value['GroupChallenge']['group_challenges_id']} AND user_id = {$user_id}");
                                
                                
                                // check if the common goal of challenge is reached by this update. If yes then update the status of challenge for all group members participating in the challenge
                                $getAllMemData = $this->GroupChallenge->find('all', array('fields' => array('SUM(GroupChallenge.moves_to_date) AS TotMemPoints'),'conditions' => array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallenge.status' => 0)));
                                
                                $totMemPoints = $getAllMemData[0][0]['TotMemPoints'];
                                
                                if($totMemPoints >= $challengesDetails['Challenge']['moves_target'])
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                    
                                }
                                
                                
                            }
                        }
                            
                            

                        }

                    }
                    
                    if($value['GroupChallenge']['challenge_type'] == '3')
                    {

                    //$challengeStartDate = $value['GroupChallenge']['start_timestamp'];
                    //$challengeEndDate = $value['GroupChallenge']['end_timestamp'];
                    
                    $challengesDetails = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $value['GroupChallenge']['challenges_id'])));
                    
                    if($challengeEndDate == '0000-00-00 00:00:00')
                    {
                            $totalDistance = $this->Move->find('all', array('fields' => array('SUM(Move.total_miles) AS tot_dist'), 'conditions' => array('Move.moves_date >=' => date('Y-m-d',$challengeStartDate), 'Move.user_id' => $user_id)));
                       
                            
                            if($value['GroupChallenge']['group_challenge_type'] == 1 || $value['GroupChallenge']['group_challenge_type'] == 2)
                        { // group challenge types Most ranking or Achievement based
                            
                            
                            if($totalDistance[0][0]['tot_dist'] >= $challengesDetails['Challenge']['moves_target'])
                        {

                                $completedChallengeData['moves_to_date'] = $totalDistance[0][0]['tot_dist'];
                            //$completedChallengeData['completed_date'] = date('Y-m-d H:i:s');
                            //$completedChallengeData['status'] = 1;

                            $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                            $this->GroupChallenge->save($completedChallengeData);

                            
                                $returnArr = array('GroupChallengeCompleted' => '2', 'group_challenge_name' => $challengesDetails['Challenge']['challenges_name']);
                                return $returnArr;

                        }else{
                            
//                            $moves_to_date = $valTillDate + $totalMets[0][0]['tot_mets'];
                                $moves_to_date =  $totalDistance[0][0]['tot_dist'];
                            
                            /*$this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                            $this->GroupChallenge->saveField('moves_to_date', $moves_to_date);*/
                                
                                $this->GroupChallenge->query("UPDATE group_challenges SET moves_to_date = {$moves_to_date} WHERE group_challenges_id = {$value['GroupChallenge']['group_challenges_id']} AND user_id = {$user_id}");
                                
                        }

                        }elseif($value['GroupChallenge']['group_challenge_type'] == 3)
                        {
                            if($totalDistance[0][0]['tot_dist'] >= $challengesDetails['Challenge']['moves_target'])
                            {

                                $completedChallengeData['moves_to_date'] = $totalDistance[0][0]['tot_dist'];
                                //$completedChallengeData['completed_date'] = date('Y-m-d H:i:s');
                                //$completedChallengeData['status'] = 1;

                                $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);
                                
                                
                                // check if the common goal of challenge is reached by this update. If yes then update the status of challenge for all group members participating in the challenge
                                $getAllMemData = $this->GroupChallenge->find('all', array('fields' => array('SUM(GroupChallenge.moves_to_date) AS TotMemPoints'),'conditions' => array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallenge.status' => 0)));
                                
                                $totMemPoints = $getAllMemData[0][0]['TotMemPoints'];
                                
                                if($totMemPoints >= $challengesDetails['Challenge']['moves_target'])
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                    
                                }

                                
                                $returnArr = array('GroupChallengeCompleted' => '2', 'group_challenge_name' => $challengesDetails['Challenge']['challenges_name']);
                                return $returnArr;

                    }else{
                        
    //                            $moves_to_date = $valTillDate + $totalMets[0][0]['tot_mets'];
                                $moves_to_date =  $totalDistance[0][0]['tot_dist'];

                                /*$this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->saveField('moves_to_date', $moves_to_date);*/
                                
                                $this->GroupChallenge->query("UPDATE group_challenges SET moves_to_date = {$moves_to_date} WHERE group_challenges_id = {$value['GroupChallenge']['group_challenges_id']} AND user_id = {$user_id}");
                                
                                
                                // check if the common goal of challenge is reached by this update. If yes then update the status of challenge for all group members participating in the challenge
                                $getAllMemData = $this->GroupChallenge->find('all', array('fields' => array('SUM(GroupChallenge.moves_to_date) AS TotMemPoints'),'conditions' => array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallenge.status' => 0)));
                                
                                $totMemPoints = $getAllMemData[0][0]['TotMemPoints'];
                                
                                if($totMemPoints >= $challengesDetails['Challenge']['moves_target'])
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                }
                                
                                
                                
                            }
                        }

                        }else{

                        $totalDistance = $this->Move->find('all', array('fields' => array('SUM(Move.total_miles) AS tot_dist'), 'conditions' => array('Move.moves_date >=' => date('Y-m-d',$challengeStartDate), 'Move.moves_date <=' => date('Y-m-d',$challengeEndDate),'Move.user_id' => $user_id)));
                       
                            
                            if($value['GroupChallenge']['group_challenge_type'] == 1 || $value['GroupChallenge']['group_challenge_type'] == 2)
                            { // group challenge types Most ranking or Achievement based


                                if($totalDistance[0][0]['tot_dist'] >= $challengesDetails['Challenge']['moves_target'])
                                {

                                        $completedChallengeData['moves_to_date'] = $totalDistance[0][0]['tot_dist'];
                                    //$completedChallengeData['completed_date'] = date('Y-m-d H:i:s');
                                    //$completedChallengeData['status'] = 1;

                                    $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                    $this->GroupChallenge->save($completedChallengeData);


                                        $returnArr = array('GroupChallengeCompleted' => '2', 'group_challenge_name' => $challengesDetails['Challenge']['challenges_name']);
                                        return $returnArr;

                                }else{

        //                            $moves_to_date = $valTillDate + $totalMets[0][0]['tot_mets'];
                                        $moves_to_date =  $totalDistance[0][0]['tot_dist'];

                                    /*$this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                    $this->GroupChallenge->saveField('moves_to_date', $moves_to_date);*/
                                        
                                    $this->GroupChallenge->query("UPDATE group_challenges SET moves_to_date = {$moves_to_date} WHERE group_challenges_id = {$value['GroupChallenge']['group_challenges_id']} AND user_id = {$user_id}");    
                                        
                                }

                            }elseif($value['GroupChallenge']['group_challenge_type'] == 3)
                            {
                                if($totalDistance[0][0]['tot_dist'] >= $challengesDetails['Challenge']['moves_target'])
                                {

                                    $completedChallengeData['moves_to_date'] = $totalDistance[0][0]['tot_dist'];
                                    //$completedChallengeData['completed_date'] = date('Y-m-d H:i:s');
                                    //$completedChallengeData['status'] = 1;

                                    $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                    $this->GroupChallenge->save($completedChallengeData);


                                    // check if the common goal of challenge is reached by this update. If yes then update the status of challenge for all group members participating in the challenge
                                    $getAllMemData = $this->GroupChallenge->find('all', array('fields' => array('SUM(GroupChallenge.moves_to_date) AS TotMemPoints'),'conditions' => array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallenge.status' => 0)));

                                    $totMemPoints = $getAllMemData[0][0]['TotMemPoints'];

                                    if($totMemPoints >= $challengesDetails['Challenge']['moves_target'])
                                    {
                                        //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                        
                                        //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                    }


                                    $returnArr = array('GroupChallengeCompleted' => '2', 'group_challenge_name' => $challengesDetails['Challenge']['challenges_name']);
                                    return $returnArr;

                        }else{

        //                            $moves_to_date = $valTillDate + $totalMets[0][0]['tot_mets'];
                                    $moves_to_date =  $totalDistance[0][0]['tot_dist'];

                                    /*$this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                    $this->GroupChallenge->saveField('moves_to_date', $moves_to_date);*/
                                    
                                    $this->GroupChallenge->query("UPDATE group_challenges SET moves_to_date = {$moves_to_date} WHERE group_challenges_id = {$value['GroupChallenge']['group_challenges_id']} AND user_id = {$user_id}");
                                    


                                    // check if the common goal of challenge is reached by this update. If yes then update the status of challenge for all group members participating in the challenge
                                    $getAllMemData = $this->GroupChallenge->find('all', array('fields' => array('SUM(GroupChallenge.moves_to_date) AS TotMemPoints'),'conditions' => array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallenge.status' => 0)));

                                    $totMemPoints = $getAllMemData[0][0]['TotMemPoints'];

                                    if($totMemPoints >= $challengesDetails['Challenge']['moves_target'])
                                    {
                                        //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                        
                                        //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                    }



                                }
                            }
                        
                        
                    }
                }
                
                // Check if challenge type is vigorous minute challenge
                if($value['GroupChallenge']['challenge_type'] == '5')
                {
                    $challengesDetails = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $value['GroupChallenge']['challenges_id'])));
                        
                        // Get user total points from start date of challenge till this time if the challenge is still active
                        $totalPoints = $this->DailyMet->find('all', array('fields' => array('SUM(DailyMet.vigorous_MET) AS points'), 'conditions' => array('DailyMet.daily_mets_timestamp >=' => strtotime($challengeStartDate), 'DailyMet.daily_mets_timestamp <=' => strtotime($challengeEndDate),'DailyMet.user_id' => $user_id)));
                        
                        
                        if($value['GroupChallenge']['group_challenge_type'] == 1 || $value['GroupChallenge']['group_challenge_type'] == 2)
                        {  // group challenge types Most ranking or Achievement based
                            if($totalPoints[0][0]['points'] >= $challengesDetails['Challenge']['moves_target'])
                            {
                                // If challenge is completed then change status of the challenge for that user
                                $completedChallengeData['moves_to_date'] = $totalPoints[0][0]['points'];
                                //$completedChallengeData['completed_date'] = date('Y-m-d H:i:s');
                                //$completedChallengeData['status'] = 1;

                                $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);
                                
                                
                                // IF challenge is Achievement based then update the status of challenge as completed if any one user reaches the goal
                                if($value['GroupChallenge']['group_challenge_type'] == 2)
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                    
                                }
                                
                                $returnArr = array('GroupChallengeCompleted' => '2', 'group_challenge_name' => $challengesDetails['Challenge']['challenges_name']);
                                return $returnArr;
                                
                            }else{

                                // If challenge is not completed then update the points of that user 
                                $completedChallengeData['moves_to_date'] = $totalPoints[0][0]['points'];
                                /*$this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);*/
                                
                                $this->GroupChallenge->query("UPDATE group_challenges SET moves_to_date = {$completedChallengeData['moves_to_date']} WHERE group_challenges_id = {$value['GroupChallenge']['group_challenges_id']} AND user_id = {$user_id}");
                                
                                $returnArr = array('GroupChallengeCompleted' => '0');
                                return $returnArr;
                            }
                        }elseif($value['GroupChallenge']['group_challenge_type'] == 3)
                        { // group challenge type collective efforts
                            if($totalPoints[0][0]['points'] >= $challengesDetails['Challenge']['moves_target'])
                            {
                                // If challenge is completed then change status of the challenge for that user
                                $completedChallengeData['moves_to_date'] = $totalPoints[0][0]['points'];
                                //$completedChallengeData['completed_date'] = date('Y-m-d H:i:s');
                                //$completedChallengeData['status'] = 1;

                                $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);
                                
                                
                                // check if the common goal of challenge is reached by this update. If yes then update the status of challenge for all group members participating in the challenge
                                $getAllMemData = $this->GroupChallenge->find('all', array('fields' => array('SUM(GroupChallenge.moves_to_date) AS TotMemPoints'),'conditions' => array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallenge.status' => 0)));
                                
                                $totMemPoints = $getAllMemData[0][0]['TotMemPoints'];
                                
                                if($totMemPoints >= $challengesDetails['Challenge']['moves_target'])
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                }
                                
                                
                                $returnArr = array('GroupChallengeCompleted' => '2', 'group_challenge_name' => $challengesDetails['Challenge']['challenges_name']);
                                return $returnArr;
                                
                            }else{
                                
                                $completedChallengeData['moves_to_date'] = $totalPoints[0][0]['points'];
                                $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);
                                
                                
                                // check if the common goal of challenge is reached by this update. If yes then update the status of challenge for all group members participating in the challenge
                                $getAllMemData = $this->GroupChallenge->find('all', array('fields' => array('SUM(GroupChallenge.moves_to_date) AS TotMemPoints'),'conditions' => array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallenge.status' => 0)));
                                
                                $totMemPoints = $getAllMemData[0][0]['TotMemPoints'];
                                
                                if($totMemPoints >= $challengesDetails['Challenge']['moves_target'])
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                    
                                }
                                
                                
                            }
                        }
                }
                
                
                // Check if challenge type is moderate minute challenge
                if($value['GroupChallenge']['challenge_type'] == '6')
                {
                    $challengesDetails = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $value['GroupChallenge']['challenges_id'])));
                        
                        // Get user total points from start date of challenge till this time if the challenge is still active
                        $totalPointsMod = $this->DailyMet->find('all', array('fields' => array('SUM(DailyMet.moderate_MET) AS points'), 'conditions' => array('DailyMet.daily_mets_timestamp >=' => strtotime($challengeStartDate), 'DailyMet.daily_mets_timestamp <=' => strtotime($challengeEndDate),'DailyMet.user_id' => $user_id)));
                        
                        $totalPointsVig = $this->DailyMet->find('all', array('fields' => array('SUM(DailyMet.vigorous_MET) AS points'), 'conditions' => array('DailyMet.daily_mets_timestamp >=' => strtotime($challengeStartDate), 'DailyMet.daily_mets_timestamp <=' => strtotime($challengeEndDate),'DailyMet.user_id' => $user_id)));
                        
                        $totalPoints[0][0]['points'] = $totalPointsMod[0][0]['points'] + $totalPointsVig[0][0]['points'];
                        
                        if($value['GroupChallenge']['group_challenge_type'] == 1 || $value['GroupChallenge']['group_challenge_type'] == 2)
                        {  // group challenge types Most ranking or Achievement based
                            if($totalPoints[0][0]['points'] >= $challengesDetails['Challenge']['moves_target'])
                            {
                                // If challenge is completed then change status of the challenge for that user
                                $completedChallengeData['moves_to_date'] = $totalPoints[0][0]['points'];
                                //$completedChallengeData['completed_date'] = date('Y-m-d H:i:s');
                                //$completedChallengeData['status'] = 1;

                                $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);
                                
                                
                                // IF challenge is Achievement based then update the status of challenge as completed if any one user reaches the goal
                                if($value['GroupChallenge']['group_challenge_type'] == 2)
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                    
                                }
                                
                                $returnArr = array('GroupChallengeCompleted' => '2', 'group_challenge_name' => $challengesDetails['Challenge']['challenges_name']);
                                return $returnArr;
                                
                            }else{

                                // If challenge is not completed then update the points of that user 
                                $completedChallengeData['moves_to_date'] = $totalPoints[0][0]['points'];
                                /*$this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);*/
                                
                                $this->GroupChallenge->query("UPDATE group_challenges SET moves_to_date = {$completedChallengeData['moves_to_date']} WHERE group_challenges_id = {$value['GroupChallenge']['group_challenges_id']} AND user_id = {$user_id}");
                                
                                $returnArr = array('GroupChallengeCompleted' => '0');
                                return $returnArr;
                            }
                        }elseif($value['GroupChallenge']['group_challenge_type'] == 3)
                        { // group challenge type collective efforts
                            if($totalPoints[0][0]['points'] >= $challengesDetails['Challenge']['moves_target'])
                            {
                                // If challenge is completed then change status of the challenge for that user
                                $completedChallengeData['moves_to_date'] = $totalPoints[0][0]['points'];
                                //$completedChallengeData['completed_date'] = date('Y-m-d H:i:s');
                                //$completedChallengeData['status'] = 1;

                                $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);
                                
                                
                                // check if the common goal of challenge is reached by this update. If yes then update the status of challenge for all group members participating in the challenge
                                $getAllMemData = $this->GroupChallenge->find('all', array('fields' => array('SUM(GroupChallenge.moves_to_date) AS TotMemPoints'),'conditions' => array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallenge.status' => 0)));
                                
                                $totMemPoints = $getAllMemData[0][0]['TotMemPoints'];
                                
                                if($totMemPoints >= $challengesDetails['Challenge']['moves_target'])
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                }
                                
                                
                                $returnArr = array('GroupChallengeCompleted' => '2', 'group_challenge_name' => $challengesDetails['Challenge']['challenges_name']);
                                return $returnArr;
                                
                            }else{
                                
                                $completedChallengeData['moves_to_date'] = $totalPoints[0][0]['points'];
                                $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                                $this->GroupChallenge->save($completedChallengeData);
                                
                                
                                // check if the common goal of challenge is reached by this update. If yes then update the status of challenge for all group members participating in the challenge
                                $getAllMemData = $this->GroupChallenge->find('all', array('fields' => array('SUM(GroupChallenge.moves_to_date) AS TotMemPoints'),'conditions' => array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallenge.status' => 0)));
                                
                                $totMemPoints = $getAllMemData[0][0]['TotMemPoints'];
                                
                                if($totMemPoints >= $challengesDetails['Challenge']['moves_target'])
                                {
                                    //$this->GroupChallenge->updateAll(array('GroupChallenge.completed_date' => date('Y-m-d H:i:s'), 'GroupChallenge.status' => 1), array('GroupChallenge.groups_id' => $value['GroupChallenge']['groups_id'], 'GroupChallenge.challenges_id' => $value['GroupChallenge']['challenges_id']));
                                    //$this->GroupChallenge->query("UPDATE group_challenges SET completed_date = '".date('Y-m-d H:i:s')."',  status = 1 WHERE groups_id = {$value['GroupChallenge']['groups_id']} AND challenges_id = {$value['GroupChallenge']['challenges_id']}");
                                    
                                }
                                
                                
                            }
                        }
                }
                
                
                    
                }    
                    
            } // for each ends here   
            }else{
                $returnArr = array('challengeCompleted' => '0');
                return $returnArr;
            }
            
        }
        
        public function startChallenge() {
             $this->autoRender = false;
            $this->layout = false;
            $this->loadModel('User');
            $this->loadModel('Group');
            $this->loadModel('Challenge');
            $this->loadModel('GroupChallenge');
            $this->loadModel('GroupChallengeInvite');
            $this->loadModel('GroupMember');
            if ($this->request->is('post')) {
                $UserId = $this->request->data['userId'];
                $UserData = $this->User->find('first', array('conditions' => array('User.id' => $UserId)));
                $AdminName = $this->decrypt($UserData['User']['username']);
                $groupId = $this->request->data['grpId'];
                $groupData = $this->Group->find('first', array('conditions' => array('Group.groups_id' => $groupId)));
                $GroupName = $groupData['Group']['groupname'];
                $challengeId = $this->request->data['challengeId'];
                $challengeData = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $challengeId)));
                 $Duration = $this->request->data['time_limit'];
                 $startDate = date("Y-m-d 00:00:00", strtotime('+24 hours', time()));
                  $groupData['start_timestamp'] = $startDate;
               
                if ($Duration > 0) {
                    $end_timestamp = date("Y-m-d H:i:s", (strtotime(date($groupData['start_timestamp'])) + $Duration));
                } else {
                    $end_timestamp = "0000-00-00 00:00:00";
                }
                $groupData['end_timestamp'] = $end_timestamp;
                $groupData['status'] = '0';
                
                $dataTosave = $this->GroupChallenge->find('all', array('conditions' => array('GroupChallenge.groups_id' => $groupId,'GroupChallenge.challenges_id'=>$challengeId)));
                if(!empty($dataTosave)){
                    foreach ($dataTosave as $key => $value) {
                        $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                        $this->GroupChallenge->save($groupData);
                    }
                    
                    // push notification
                    $groupUsersData = $this->GroupChallengeInvite->find('all',array('conditions'=>array('GroupChallengeInvite.groups_id'=>$groupId,'GroupChallengeInvite.challenges_id'=>$challengeId,'GroupChallengeInvite.status'=>1)));
                    if(!empty($groupUsersData)){
                       // print_r($groupUsersData);die;
                        foreach ($groupUsersData as $key => $value) {
                            $userDataEmail = $this->User->find('first',array('conditions'=>array('User.id'=>$value['GroupChallengeInvite']['user_id'])));
                        
                            // email
                            if($userDataEmail['User']['id'] == $UserId){
                              
                          }else{
                               $ToEmail = $this->decrypt($userDataEmail['User']['email']);
                                $username = $this->decrypt($userDataEmail['User']['username']).' '.$this->decrypt($userDataEmail['User']['surname']);
                                $params = array('to' => $ToEmail, 'Firstname' => $username, 'user_id' => $userDataEmail['User']['id']);
                                $haystack = array('[UserName]','[GroupAdminName]','[ChallengeName]','[Date]','[DOMAIN_NAME]');
                                $replace = array($username,$AdminName,$challengeData['Challenge']['challenges_name'],$startDate,BASEURL);
                                $this->SendEmail('start_group_challenge', $params, $haystack, $replace); 
                                
                          } 
                               
                                // email notification end
                            // push notify starts here
                             if($userDataEmail['User']['platform'] == 'Android'){
                          if($userDataEmail['User']['id'] == $UserId){
                              
                          }else{
                              $status = 'ForStartChallengePushNotify';
                              $timestamp = strtotime($startDate);
                              $this->requestAction('/Push/push_android/' . $userDataEmail['User']['id'].'/'.$AdminName.'/'.$GroupName.'/'.$groupId.'/'.$challengeId.'/'.$challengeData['Challenge']['challenges_name'].'/'.$status.'/'.$timestamp);
                               $response['status'] = '1';  
                              
                          }
                          
                     }else{
                              $ArrToSend['userId'] = $userDataEmail['User']['id'];
                              $ArrToSend['adminName'] = $AdminName;
                              $ArrToSend['challengeName'] = $challengeData['Challenge']['challenges_name'];
                              $ArrToSend['groupName'] = $GroupName;
                              $ArrToSend['groupId'] = $groupId;
                              $ArrToSend['Date'] = $startDate;
                              $ArrToSend['challengeId'] = $challengeId;
                              $ArrToSend['flag'] = 'start_challenge';
                              $ArrToSend['message'] = $challengeData['Challenge']['challenges_name'].' created by '.$GroupName.' will start on '.$startDate.' and you can check your progress in Challenge Manager section. Touch for details';
                              //$this->requestAction('/Push/send_push_notification/'. $ArrToSend);
                              $this->requestAction(
                            array('controller' => 'Push', 'action' => 'send_push_notification'),
                                array('pass' => $ArrToSend)
                                    );
                               $response['status'] = '1';
                          } // push notify ends here
                          
                          }
                       
                    }
                    
                    
                  return json_encode($response);
                }else{
                     $response['status'] = '0';
                  return json_encode($response);
                }
            }
        }
        
        public function checkChallengeStatus() {
              $this->autoRender = false;
            $this->layout = false;
            $this->loadModel('User');
            $this->loadModel('Group');
            $this->loadModel('Challenge');
            $this->loadModel('GroupChallenge');
            $this->loadModel('GroupChallengeInvite');
            $this->loadModel('GroupMember');
            if ($this->request->is('post')) {
                $groupId = $this->request->data['grpId'];
                $challengeId = $this->request->data['challengeId'];
                $dataTosave = $this->GroupChallenge->find('first', array('conditions' => array('GroupChallenge.groups_id' => $groupId,'GroupChallenge.challenges_id'=>$challengeId)));
                if(!empty($dataTosave)){
                    if($dataTosave['GroupChallenge']['start_timestamp'] == '0000-00-00 00:00:00'){
                         $response['status'] = '0';
                         return json_encode($response);
                    }else{
                         $response['status'] = '1';
                         return json_encode($response);
                    }
                }else{
                     $response['status'] = '2';
                    return json_encode($response);
                }
            }
        }
        
        public function getUsername() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $userIds = $this->request->data['UserIds'];
        $IdArr = explode(",", $userIds);
        for ($i = 0; $i < sizeof($IdArr); $i++) {
            $dataUser[] = $this->User->find('first', array('conditions' => array('User.id' => $IdArr[$i])));
        }
        if(!empty($dataUser)){
            
            foreach ($dataUser as $key => $value)
               {
                
                $UserData[$key]['name'] = $this->decrypt($value['User']['username']).' '.$this->decrypt($value['User']['surname']);
                $UserData[$key]['id'] = $value['User']['id'];
            }
            $response['status']='1';
            $response['data']=$UserData;
            return json_encode($response);
        }else{
             $response['status'] = '0';
                    return json_encode($response);
        }
    }
    
    public function resendGroupNotification() {
         $this->autoRender = false;
            $this->layout = false;
            $this->loadModel('User');
            $this->loadModel('Group');
            $this->loadModel('Challenge');
            $this->loadModel('GroupChallenge');
            $this->loadModel('GroupChallengeInvite');
            $this->loadModel('GroupMember');
            if ($this->request->is('post')) {
                $groupId = $this->request->data['grpId'];
                $userId = $this->request->data['userId'];
                $AdminId = $this->request->data['AdminId'];
                  $AdminDetails = $this->User->find('first', array('conditions' => array('User.id' => $AdminId)));  
                  $AdminName = $this->decrypt($AdminDetails['User']['username']);
                  $userDataEmail = $this->User->find('first', array('conditions' => array('User.id' => $userId)));
                  $groupData = $this->Group->find('first', array('conditions' => array('Group.groups_id' => $groupId)));  
                  $GroupName =  $groupData['Group']['groupname'];
                  $groupMemberData = $this->GroupMember->find('first', array('conditions' => array('GroupMember.groups_id' => $groupId,'GroupMember.user_id'=>$userId))); 
                  
                  // email notification
                               $ToEmail = $this->decrypt($userDataEmail['User']['email']);
                                $username = $this->decrypt($userDataEmail['User']['username']);
                                $params = array('to' => $ToEmail, 'Firstname' => $username, 'user_id' => $userDataEmail['User']['id']);
                                $haystack = array('[UserName]','[GroupName]' ,'[GroupAdminName]','[DOMAIN_NAME]');
                                $replace = array($username,$GroupName,$AdminName, BASEURL);
                                $this->SendEmail('group_invitation', $params, $haystack, $replace);  // email notification
                    
                     if($userDataEmail['User']['platform'] == 'Android'){
                              $this->requestAction('/Push/push_android/' . $userDataEmail['User']['id'].'/'.$AdminName.'/'.$GroupName.'/'.$groupId);
                     }else{
                              $ArrToSend['userId'] = $userDataEmail['User']['id'];
                              $ArrToSend['adminName'] = $AdminName;
                              $ArrToSend['groupName'] = $GroupName;
                              $ArrToSend['groupId'] = $groupId;
                              $ArrToSend['flag'] = 'create_group';
                              $ArrToSend['message'] = 'You have been invited to join the '.$GroupName.' group created by '.$AdminName.'. Touch for details';
                              //$this->requestAction('/Push/send_push_notification/'. $ArrToSend);
                              $this->requestAction(
                                        array('controller' => 'Push', 'action' => 'send_push_notification'),
                                        array('pass' => $ArrToSend)
                                            );
                     }
                     
                     $data['status'] = 2;
                     $this->GroupMember->id = $groupMemberData['GroupMember']['group_members_id'];
                     if($this->GroupMember->save($data)){
                         $response['status'] = '1';
                                  return json_encode($response);
                     }else{
                         $response['status'] = '0';
                                  return json_encode($response);
                     }
            }else{
                                $response['status'] = '0';
                                  return json_encode($response);
            }
    }

    
    
    public function groupChallengeTrophies()
    {
        $this->autoRender = false;
        $this->layout = false;
        
        if ($this->request->is('post')) 
        {
            
            
            
            $this->loadModel('User');
            $this->loadModel('TrophyCabinet');
            $this->loadModel('GroupChallenge');
            $this->loadModel('Challenge');
            
            $challengesArr = array();
            
            $userId = $this->request->data['userId'];
            
            $userDetails = $this->User->find('first', array('conditions' => array('User.user_id' => $userId)));
            
            $groupChallengeDetails = $this->GroupChallenge->find('all', array('conditions' => array('GroupChallenge.user_id' => $userDetails['User']['id'], 'GroupChallenge.status' => 1)));
            
            if(!empty($groupChallengeDetails))
            {
                
                
                foreach($groupChallengeDetails as $key => $groupComp)
                {
                    if($groupComp['GroupChallenge']['status'] == '1'){
                    //$challengeDetails = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $groupComp['GroupChallenge']['challenges_id'])));
                    $TrophyCabinet = $this->TrophyCabinet->find('first', array('conditions' => array('TrophyCabinet.challenges_id' => $groupComp['GroupChallenge']['challenges_id'])));
                    

                    $challengesArr[$key][$TrophyCabinet['TrophyCabinet']['challenges_id']] = $TrophyCabinet['TrophyCabinet'];
                }
                    
                }
            }
      //    print_r($groupChallengeDetails);die;
            $response['status']='1';
            $response['data']=$challengesArr;
            return json_encode($response);
            
        }else{
            $response['status']='0';
            $response['data']=array();
            return json_encode($response);
        }
        
        
    }
    
    
    public function deletegroup() {
         $this->autoRender = false;
        $this->layout = false;
        
        if ($this->request->is('post')) 
        {
            
            $this->loadModel('User');
            $this->loadModel('Group');
            $this->loadModel('Challenge');
            $this->loadModel('GroupChallenge');
            $this->loadModel('GroupChallengeInvite');
            $this->loadModel('GroupMember');
            
            $groupId = $this->request->data['groupId'];
            
            $ActiveGroups = $this->Group->find('first',array('conditions'=>array('Group.groups_id'=>$groupId,'Group.status'=>array(0,1,2))));
            if(!empty($ActiveGroups)){
                    $data['status'] = 9;
                    $this->Group->id = $ActiveGroups['Group']['groups_id'];
                    if($this->Group->save($data)){
                        $GroupMembers = $this->GroupMember->find('all',array('conditions'=>array('GroupMember.groups_id'=>$groupId)));
                        if(!empty($GroupMembers)){
                            foreach ($GroupMembers as $key => $value) {
                                 $this->GroupMember->id = $value['GroupMember']['group_members_id'];
                                 $this->GroupMember->save($data); 
                            }
                        }
                     }
                     
                $groupchallenge =  $this->GroupChallenge->find('all',array('conditions'=>array('GroupChallenge.groups_id'=>$groupId)));    
                if(!empty($groupchallenge)){
                    foreach ($groupchallenge as $key => $value) {
                        $dataTosave['status'] = 2;
                        $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                        $this->GroupChallenge->save($dataTosave);
                    }
                }
                $groupInvites = $this->GroupChallengeInvite->find('all',array('conditions'=>array('GroupChallengeInvite.groups_id'=>$groupId)));    
                if(!empty($groupInvites)){
                    foreach ($groupInvites as $key => $value) {
                        $SavedData['status'] = 9;
                        $this->GroupChallengeInvite->id = $value['GroupChallengeInvite']['group_challenge_invites_id'];
                        $this->GroupChallengeInvite->save($SavedData);
                    }
                }
                 $response['status']='1';
                 return json_encode($response); 
            }else{
                 $response['status']='0';
                 return json_encode($response);
            }
        }
    } 
    
    public function checkGroupChallengeExpiry() {
         $this->autoRender = false;
        $this->layout = false;
    
        if ($this->request->is('post')) 
        {
    
            $this->loadModel('User');
            $this->loadModel('Group');
            $this->loadModel('Challenge');
            $this->loadModel('GroupChallenge');
            $this->loadModel('GroupChallengeInvite');
            $this->loadModel('GroupMember');
            
            $userId = $this->request->data['userId'];
             $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $userId)));

            $IsValidChallenge = $this->GroupChallenge->find('all', array('conditions' => array('GroupChallenge.user_id' => $UserData['User']['id'], 'GroupChallenge.status' => 0)));

            if (!empty($IsValidChallenge)) {
                
                foreach ($IsValidChallenge as $key => $value) {
                     $chalData = $this->Challenge->find('first', array('conditions' => array('Challenge.challenges_id' => $value['GroupChallenge']['challenges_id'])));

                    if ($value['GroupChallenge']['end_timestamp'] != '0000-00-00 00:00:00') {
                    $current_timestamp = date('Y-m-d H:i:s');
                        if ($current_timestamp >= $value['GroupChallenge']['end_timestamp']) {
                            $saveItem['status'] = '4';
                            $this->GroupChallenge->id = $value['GroupChallenge']['group_challenges_id'];
                        $this->GroupChallenge->save($saveItem);
                        $data['challengeDiscard'] = '1';
                        $data['challengeName'] = $chalData['Challenge']['challenges_name'];
                        $dataToSave['status'] = 0;
                            $this->Group->id = $value['GroupChallenge']['groups_id'];
                        $this->Group->save($saveItem);
                            
                            
//                            $getAllusers = $this->GroupChallengeInvite->find('all', array('conditions' => array('GroupChallengeInvite.challenges_id' => $value['GroupChallenge']['challenges_id'],'GroupChallengeInvite.groups_id'=>$value['GroupChallenge']['groups_id'])));
//                            if(!empty($getAllusers)){
//                                foreach ($getAllusers as $key => $value1) {
//                                    $SaveTodata['status'] = 0;
//                                    $this->GroupChallengeInvite->id = $value1['GroupChallengeInvite']['group_challenge_invites_id'];
//                                    $this->GroupChallengeInvite->save($SaveTodata);
//}
//                }
                            
                }
                    }
                }
                
               
                
                
            }else {
                $data['challengeDiscard'] = '0';
            }
         echo json_encode($data);
        }
    }
    
    
    public function checkChallengeResultStatus() { 
        
//        Configure::write('debug', 2);
         $this->autoRender = false;
        $this->layout = false;
        
        if ($this->request->is('post')) 
        {
            
            $this->loadModel('User');
            $this->loadModel('GroupChallenge');
            $this->loadModel('AcceptedChallenge');
            // $this->AcceptedChallenge->unBindModel(array('belongsTo' => array('Challenge')));
            $userId = $this->request->data['userId'];
            $userDetails = $this->User->find('first', array('conditions' => array('User.user_id' => $userId)));
            $ChallengeDetails = $this->AcceptedChallenge->find('first', array(
                'conditions' => array('AcceptedChallenge.user_id' => $userDetails['User']['id'],'AcceptedChallenge.challenge_result_status IN (1,2)'),
                'order'=>array('AcceptedChallenge.accepted_challenges_id DESC')));
          //  print_r($ChallengeDetails);
           
            if(!empty($ChallengeDetails)){
                $saveItem['AcceptedChallenge']['challenge_result_status'] = 0;
                $this->AcceptedChallenge->id = $ChallengeDetails['AcceptedChallenge']['accepted_challenges_id'];
               if($this->AcceptedChallenge->save($saveItem)){
                   $data['banner'] = $ChallengeDetails['Challenge']['banner'];
                   $data['banner_base64'] = $ChallengeDetails['Challenge']['banner_base64'];
                   $data['status'] = $ChallengeDetails['AcceptedChallenge']['challenge_result_status'];
                   $data['challenges_name'] = $ChallengeDetails['Challenge']['challenges_name'];
                   return json_encode($data);
               }else{
                   $data['status'] = '01';
                   return json_encode($data);
                }
            }else{
                $data['status'] = '0';
                   return json_encode($data);
            }
        }
    }
    
    public function checkGroupChallengeResultStatus() { 
        
        
         $this->autoRender = false;
        $this->layout = false;
        
        if ($this->request->is('post')) 
        {
            
            $this->loadModel('User');
            $this->loadModel('GroupChallenge');
            $this->loadModel('Challenge');
           // $this->loadModel('AcceptedChallenge');
             $this->GroupChallenge->bindModel(array(
                 'belongsTo' => array('Challenge'=>array(
                        'className' => 'Challenge',
                        'foreignKey' => false,
                        'conditions' => array(
                                'GroupChallenge.challenges_id = Challenge.challenges_id'
                 ))))); 
             
             
            $userId = $this->request->data['userId'];
            $userDetails = $this->User->find('first', array('conditions' => array('User.user_id' => $userId)));
            $ChallengeDetails = $this->GroupChallenge->find('all', array(
                'conditions' => array('GroupChallenge.user_id' => $userDetails['User']['id'],'GroupChallenge.challenge_result_status IN (1,2)'),
                'order'=>array('GroupChallenge.group_challenges_id DESC')));
//            print_r($ChallengeDetails);die;
           
            if(!empty($ChallengeDetails)){
                foreach ($ChallengeDetails as $key => $arr) {
                    $saveData['challenge_result_status'] = 0;
                     $this->GroupChallenge->id = $arr['GroupChallenge']['group_challenges_id'];
                     $this->GroupChallenge->save($saveData);
                      $data['banner'] = $arr['Challenge']['banner'];
                      $data['banner_base64'] = $arr['Challenge']['banner_base64'];
                      $data['status'] = $arr['GroupChallenge']['challenge_result_status'];
                      $data['challenges_name'] = $arr['Challenge']['challenges_name'];
                     $Newdata[$key] = $data;
                }
                return json_encode($Newdata);
            }else{
                $data['status'] = '0';
                   return json_encode($data);
            }
        }
    }
    
    
     public function searchUser() {
        Configure::write('debug', 2);
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('GroupMember');
        $userId = $this->request->data['UserId'];
        $existsUser = $this->User->find('first', array('conditions' => array('User.user_id' => $userId)));
        $userId = $existsUser['User']['id'];
       
      
        $username = $this->request->data['searchName'];
        $username = isset($username) ? $username : '';
       
        $snm = '';
       
       
          if(preg_match('/\s/',$username)){
                    $arrName = explode(' ', $username);
                    $username = $arrName[0];
                    $snm = $arrName[1];
                }
               
                $allSmall = $this->encrypt(strtolower($username));
                $allCaps = $this->encrypt(strtoupper($username));
                $FirstCharOfStr = $this->encrypt(ucfirst(strtolower($username)));
                $FirstChCaps = $this->encrypt(ucwords(strtolower($username)));
                $normal = $this->encrypt($username);
               
                // condition to check for my created group and invited group
                   
                $groupIds =  $this->GroupMember->find('all', array('conditions' => array('GroupMember.user_id' => $userId),'fields'=>array('GroupMember.groups_id')));
                $group_id_Str = '';
                $group_id_Str1 = '';
                if(!empty($groupIds)){
                      foreach ($groupIds as $grp) {
                            $group_id_Str .= $grp['GroupMember']['groups_id'].',';
                        }
                        $group_id_Str = rtrim($group_id_Str,',');
                    $MygroupUserIds = $this->GroupMember->find('all', array('conditions' => array("GroupMember.groups_id IN ({$group_id_Str})"),'fields'=>array('GroupMember.user_id')));
                     
                     $MygroupUserIds = Set::classicExtract($MygroupUserIds, '{n}.GroupMember.user_id');
                   
                    
                    $MygroupUserIds = array_unique($MygroupUserIds); 
                   
                   
                    foreach ($MygroupUserIds as $key => $value) {
                        $group_id_Str1 .= $MygroupUserIds[$key].',';
                    }
                           
                      
                        $MygroupUserIds = rtrim($group_id_Str1,',');
                   
                }else{
                    $MygroupUserIds = '';
                }
               
             
               
                // end
               
                if(!empty($snm)){
                    $allSmallSn = $this->encrypt(strtolower($snm));
                    $allCapsSn = $this->encrypt(strtoupper($snm));
                    $FirstCharOfStrSn = $this->encrypt(ucfirst(strtolower($snm)));
                    $FirstChCapsSn = $this->encrypt(ucwords(strtolower($snm)));
                    $normalSn = $this->encrypt($snm);
                   
                    $allSmallArr2 = $this->User->find('all', array('conditions' => "( User.surname = '{$allSmallSn}' OR User.surname = '{$allCapsSn}' OR "
                        . "User.surname = '{$FirstCharOfStrSn}' OR User.surname = '{$FirstChCapsSn}' OR User.surname = '{$normalSn}' "
                        . ") AND User.opt_in = 1 AND User.opt_in_my_group = 1 AND User.id IN ({$MygroupUserIds}) AND User.id != $userId"  ));
                   
                }
               
                $allSmallArr = $this->User->find('all', array('conditions' => "(User.username = '{$allSmall}' OR User.username = '{$allCaps}' OR "
                        . "User.username = '{$FirstCharOfStr}' OR User.username = '{$normal}' OR User.username = '{$FirstChCaps}' OR User.surname = '{$allSmall}' OR User.surname = '{$allCaps}' OR "
                        . "User.surname = '{$FirstCharOfStr}' OR User.surname = '{$normal}' OR User.surname = '{$FirstChCaps}' "
                        . ") AND User.opt_in = 1 AND User.opt_in_my_group = 1 AND User.id IN ({$MygroupUserIds}) AND User.id != $userId" ));
               
              
                if(!empty($snm)){
                $finalArr = array_merge($allSmallArr2, $allSmallArr );
                }else{
                $finalArr = $allSmallArr;
                }
               
               
               
                foreach ($finalArr as $key => $value) {
                    $finalArr[$key]['User']['username'] = $this->decrypt($value['User']['username']).' '.$this->decrypt($value['User']['surname']);
                }
               
                echo json_encode($finalArr);
               
           
    }
    
}
