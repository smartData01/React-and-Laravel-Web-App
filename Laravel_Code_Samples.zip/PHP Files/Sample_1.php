<?php
$showFormTag = ($_SERVER['PHP_SELF'] == '/vhqv2/appointmentsPharmacist.php') ? true : false;

//function added for Cross Site Request Forgery (CSRF) attacks
function genTokenPhtest() {
    $token_time = time();
    $token_phtest = $_SESSION['token_phtest'] = md5(uniqid(mt_rand(), true)) . ',' . $token_time;
    $_SESSION['token_timestamp'] = $token_time;
    return $token_phtest;
}
?>
<script>
    $(document).ready(function() {
        $('#CarryoutCancelBtn').click(function() {
            if (confirm('Do you want to go back without saving changes?')) {
                window.location = "index.php"
            }
        });
    });
    $('#server-errors').hide();
    $('#server-errors-ht').hide();
    $('#server-errors-wt').hide();
    $('#server-errors-ht-out').hide();
    $('#server-errors-wt-out').hide();
    $('#server-errors-bmi-out').hide();
    $('#server-errors-ht-notmatched').hide();
    $('#server-errors-wt-notmatched').hide();
    $('#client-errors').hide();
</script>
<script language="javascript" type="text/javascript" src="../js/bmival.js"></script>
<?php if ($showFormTag) : ?>
    <form id="PharmTest" name="PharmTest" method="post" action="" autocomplete="off">
        <!-- <form name="PharmTest" method="post" action=""> -->
    <?php endif; ?>
    <?php
//session_unregister("selectedCalDate");
    unset($_SESSION["selectedCalDate"]);
    $root = realpath($_SERVER["DOCUMENT_ROOT"]);
    /*     * **************************************************************************************** */
    if ($_SESSION['SearchCXID']) {
        //get saccode from customer table.. 
        $cxdata = getRow(Customer, CustomerID, $_SESSION[SearchCXID]);
        //get saccode ID from saccode table . sac20199

        $sacdata = getRow(SacCode, SacCode, $cxdata['SacCode']);
        //get testtype ID .
        $sactestdata = getRow(SacCodeIncludedTests, SacCodeID, $sacdata['SacCodeID']);
        $CustAppointmentID = escape_str($_SESSION['CustAppointmentID']);
        $record = mysql_query("SELECT TestTypeID FROM CustAppointments WHERE CustAppointmentsID ='" . $CustAppointmentID . "'");
        $row = mysql_fetch_array($record);
        $testtypeid = $row[TestTypeID];

        $testtypedata = getRow(TestTypes, id, $testtypeid);

        // echo "check : ".$testtypedata['testTypeValidation'];
        if ($testtypedata['carryout_validations'] == 1) {
            $_SESSION['sactesttype'] = $testtypeid;
        } else {
            $_SESSION['sactesttype'] = "";
        }
    }
    /*     * ***************************************************************************************** */

    include_once( "../content/RTHv2/classes/metric_updates.php");
    include_once( "../content/RTHv2/classes/metric_updates_body_mass.php");
    include_once('../content/RTHv2/classes/audit_logging.php');
    include_once("$root/processors/TableCalls.php");
    include_once("../vhqv2/appsys/appointmentfunctions.php");
    include_once("$root/processors/QPosition.php");

    $alog = new auditlog();
//button commands

    if (isset($_REQUEST['btnUpdateFunction']) && (($_REQUEST['btnUpdateFunction'] != "Cancel") && ($_REQUEST['btnUpdateFunction'] != "Save and Back to homepage") && ($_REQUEST['btnUpdateFunction'] != "Continue to results"))) {

        header($_SERVER['SERVER_PROTOCOL'] . ' 403 Forbidden');
        Header("Location: ../404page.php");
    }

    if (isset($_POST[btnDoTest]) || isset($_POST[btnDoTest_x]) || $_SESSION['PharmTestStatus'] == "DoTest") {
        if ($_POST[HiddenCustAppointmentsID] != "") {

            $_SESSION[CustAppointmentID] = $_POST[HiddenCustAppointmentsID];
        } elseif ($_POST[HiddenCustAppointmentsID2] != "") {
            $custAppID = decrypt($_POST['HiddenCustAppointmentsID2']);
            $_SESSION['CustAppointmentID'] = $custAppID;
            //exit();
        }

        $CustAppointmentID = escape_str($_SESSION['CustAppointmentID']);
        //echo "SELECT * FROM CustAppointments WHERE CustAppointmentsID ='".$CustAppointmentID."'";
        //echo "CustAppointmentId ".$CustAppointmentID;


        /* =========//Functionality to redirect on 404 page if appointment id is not exists into database //=========== */
        $record = mysql_query("SELECT * FROM CustAppointments WHERE CustAppointmentsID ='" . $CustAppointmentID . "'");
        if (mysql_num_rows($record) == 0) {
            //If appointment is not exist into database then this page will redirect on 404 page.
            header('Location: ../404page.php');
        }
        /* ====================== */
        /* ====== Query use to get the appointment Location id============= */
        $AppLocQuery = "SELECT LocID,AppClinics.ClinID,ClinicRooms.AppRoomID FROM `CustAppointments` INNER JOIN ClinicRooms ON ClinicRooms.AppRoomID = `CustAppointments`.`AppRoomID` INNER JOIN AppClinics ON AppClinics.ClinID = ClinicRooms.ClinId WHERE `CustAppointmentsID`='$CustAppointmentID'";
        $AppLocResult = mysql_query($AppLocQuery);
        $AppLocQueryArray = mysql_fetch_array($AppLocResult, MYSQL_ASSOC);
        $AppLocId = $AppLocQueryArray['LocID'];
        /* ================================================================= */
        //Functionality to get the partner clinics locations.
        $locationArray = array();
        $partnerLocations = "SELECT LocationID FROM PartnerLocationLinkList WHERE PartnerID ='" . $_SESSION['PartnerID'] . "'";
        $PartnerClinics = mysql_query($partnerLocations);
        //$PartnerClinicsArray=mysql_fetch_array($PartnerClinics);
        while ($row123 = mysql_fetch_array($PartnerClinics, MYSQL_ASSOC)) {
            array_push($locationArray, $row123['LocationID']);
        }
        if (!in_array($AppLocId, $locationArray)) {
            //if appoint location id is not match with partner location id the page will redirect on 404 page.
            header('Location: ../404page.php');
        }



        while ($row = mysql_fetch_array($record)) {
            $_SESSION['TestTypeSearch'] = $row[TestTypeID];
            $_SESSION['SearchCXID'] = $row[CxID];
        }
        if ($_SESSION['TestTypeSearch'] == 1) {
            unset($_SESSION['SampleCustomer']);
            include_once("../processors/customerFunctions/customerClass.php");
            $SampleCustomer = new customerClass($_SESSION['SearchCXID']);
            $_SESSION['SampleCustomer'] = serialize($SampleCustomer);
            $_SESSION['PharmTestStatus'] = "roadtohealthHRA";
        } else {
            unset($_SESSION['bpm']);
            unset($_SESSION['bpm1']);
            unset($_SESSION[bio]);
            unset($_SESSION[bg]);
            unset($_SESSION[chol]);
            unset($_SESSION[lipids]);
            unset($_SESSION['BMClass']);
            $_SESSION['PharmTestStatus'] = "ShowTests";
        }
    } elseif ($_POST['btnTestCompleted'] || $_POST['btnTestCompleted_x']) {
        if ($_POST['HiddenCustAppointmentsID2'] != "") {
            $_SESSION['CustAppointmentID'] = decrypt($_POST['HiddenCustAppointmentsID2']);
        }

        $_SESSION['PharmTestStatus'] = "ShowConfirm";
    } elseif ($_POST['btnBackbookTime'] || $_SESSION['CorpClinicViewID'] == "") {
        $_SESSION['PharmTestStatus'] = "FindLocation";
    } elseif ($_REQUEST['btnUpdateFunction'] == "Cancel") {
        $_SESSION['PharmTestStatus'] = "START";
        header('Location:/vhqv2/index.php');
    } elseif (($_REQUEST['btnUpdateFunction'] == "Save and Back to homepage")) {


        $SQL = "SELECT SacCode FROM Partner WHERE id = " . $_SESSION['PartnerID'];
        $query = mysql_query($SQL);
        $sacode = mysql_fetch_array($query);
        //print_r($sacode);echo "<br>";
        $SQL1 = "SELECT show_gplink FROM SacCodePartners WHERE SacCodePartners = '" . $sacode['SacCode'] . "'";
        $query1 = mysql_query($SQL1);
        $gp_link = mysql_fetch_array($query1);



        //  #Reason: Conditions added for Cross Site Request Forgery (CSRF) attacks
        if (strpos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST'])) {
            //Nothing
        } else {
            header($_SERVER['SERVER_PROTOCOL'] . ' 403 Forbidden');
            Header("Location: ../../404page.php");
        }
        if (isset($_POST['token_phtest']) && $_POST['token_phtest'] != $_SESSION['token_phtest']) {

            header($_SERVER['SERVER_PROTOCOL'] . ' 403 Forbidden');
            Header("Location: ../../../404page.php");
        }
        /* else{            
          header($_SERVER['SERVER_PROTOCOL'] . ' 403 Forbidden');
          Header( "Location: ../../../404page.php" );
          //echo "<html><head><title>CSRF attack</title></head><body>CSRF attack.</body></html>";
          } */

        screen_save_blood_pressure_multi();
        screen_save_cholesterol();
        screen_save_blood_glucose();
        screen_save_height_weight();



        $Error = false;
        $sql = "SELECT * FROM TestTypeCompLink INNER JOIN TestComps ON TestComps.TestCompID = TestTypeCompLink.CompID WHERE TestTypeID = " . $_SESSION['TestTypeSearch'];
        $recordset = mysql_query($sql);

        //get testtype id for pru vaitality brand
        //$sqltesttype = "SELECT id FROM TestTypes WHERE Name = 'Vitality Healthcheck' limit 1";
        //$rectesttype = mysql_query($sqltesttype);  
        //$rowtesttype = mysql_fetch_array($rectesttype);
        //$testtypeid = $rowtesttype['id'];  
        //$testtypeid = $_SESSION['sactesttype'];
        if ($_SERVER['HTTP_HOST'] == 'www.dev.roadtohealth.co.uk' || $_SERVER['HTTP_HOST'] == 'www.qa1.roadtohealth.co.uk') {
            $testtypeid = '9235'; #QA Test type
        } else {
            $testtypeid = '98'; #Live Test type
        }

        //get componant id for pru vaitality brand
        $sqlcompo = "SELECT TestCompID  FROM TestComps WHERE TestCompName = 'Cotiniene' limit 1";
        $reccompo = mysql_query($sqlcompo);
        $rowcompo = mysql_fetch_array($reccompo);
        $compoid = $rowcompo['TestCompID'];

        //if($_SESSION['TestTypeSearch'] != $testtypeid){

        while ($row = mysql_fetch_array($recordset)) {

            if ($row[TestCompID] == 7) {
                /* if(validate_blood_pressure_multi() == false)
                  {
                  $Error = true;
                  }
                  } */

                $validatebp = validate_blood_pressure_multi();
                //echo $_SESSION['TestTypeSearch']."--".$testtypeid;
                //if testtype is not belong to pruvitality.. date :11-02-2013
                if ($_SESSION['TestTypeSearch'] == $testtypeid) {
                    if ($validatebp == 'empty' || $validatebp == 'outofrange' || $validatebp == 'higherD') {//Add diastolic heigher condition #Santosh kumar #18-02-2013
                        //echo "hello";
                        $Error = true;
                    }
                } else {
                    if ($validatebp == 'empty' || $validatebp == 'outofrange' || $validatebp == 'higherD') {//Add diastolic heigher condition #Santosh kumar #18-02-2013
                        $Error = true;
                    }
                }
                
            } elseif ($row[TestCompID] == 4) {
                // echo $_SESSION['TestTypeSearch']."--".$testtypeid;
                $validateCholesterolInput = validate_cholesterol_input();
                //echo "1".$validateCholesterolInput;
                //if testtype is not belong to pruvitality.. date :11-02-2013
                if ($_SESSION['TestTypeSearch'] == $testtypeid) {
                    if ($validateCholesterolInput == 'empty' || $validateCholesterolInput == 'outofrange' || $validateCholesterolInput == 'higherD') {
                        //echo "2";
                        $Error = true;
                    }
                } else {//echo "3";
                    if ($validateCholesterolInput == 'empty' || $validateCholesterolInput == 'outofrange' || $validateCholesterolInput == 'higherD') {

                        $Error = true;
                    }
                }
            } elseif ($row[TestCompID] == 1) {
                $validateBloodGlucoseInput = validate_blood_glucose_input();
                //echo "1".$validateBloodGlucoseInput;
                //if testtype is not belong to pruvitality.. date :11-02-2013
                if ($_SESSION['TestTypeSearch'] == $testtypeid) {
                    if ($validateBloodGlucoseInput == 'empty' || $validateBloodGlucoseInput == 'outofrange') {

                        $Error = true;
                    }
                } else {
                    if ($validateBloodGlucoseInput == 'empty' || $validateBloodGlucoseInput == 'outofrange') {

                        $Error = true;
                    }
                }
            } elseif ($row[TestCompID] == 10) {
                $a = validate_height_weight_screen();
                //echo "1".$a;
                if ($a != "") {
                    $validateHeightWeightScreen = validate_height_weight_screen();
                } else {
                    $validateHeightWeightScreen = validate_waist_hips_screen();
                }
                //echo "1".$validateHeightWeightScreen;
                //if testtype is not belong to pruvitality.. date :11-02-2013
                if ($_SESSION['TestTypeSearch'] == $testtypeid) { //echo "1";
                    if ($validateHeightWeightScreen == 'empty' || $validateHeightWeightScreen == 'outofrange') {
                        //if ($validateHeightWeightScreen == false) {
                        //echo "2";
                        $Error = true;
                    }
                } else {
                    //added 18-02-2013
                    if ($validateHeightWeightScreen == 'empty' || $validateHeightWeightScreen == 'outofrange') {

                        $Error = true;
                    }
                }
            } elseif ($row[TestCompID] == $compoid) {
                //53 co,ponantid

                $validatecotinieneInput = validate_cotiniene_input();


                if ($validatecotinieneInput == 'notint') {
                    // show_cotiniene_entry(true);
                    $Error = true;
                } elseif ($validatecotinieneInput == 'outofrange') {


                    $Error = true;
                }
            }
        }

        // add on 20 feb 2015 due to mandatory validate request
        if (validate_signature() == false) {

            $Error = true;
        }

//        if ($_SESSION['TestTypeSearch'] != $testtypeid) {
//                             if($gp_link['show_gplink'] == 1){
//                             $check_validate = validate_clinical_follow();
//                                if($check_validate == 'empty'){
//                                          //  clinical_followup(true);
//                                            $Error = true;
//                                    }
//                             }
//            if (validate_signature() == false) {
//                $Error = true;
//            }
//        } else {
//                              if($gp_link['show_gplink'] == 1){
//                              $check_validate = validate_clinical_follow();
//                                if($check_validate == 'empty'){
//                                         //   clinical_followup(true);
//                                            $Error = true;
//                                    }
//                              }
//            if ($_POST['AuditSignature'] != "") {
//                if (validate_signature() == false) {
//                    $Error = true;
//                }
//            }
//        }
        //}


        if ($Error == false) {

            $_SESSION['PharmTestStatus'] = "ValidateSave";
            //header('Location:/vhq/index.php');
        } else {

            $_SESSION['PharmTestStatus'] = "ValidateFalse";
        }
    } elseif (($_REQUEST['btnUpdateFunction'] == "Continue to results")) {//echo "continue resultxx :";print_r($_POST);
        //  #Reason: Conditions added for Cross Site Request Forgery (CSRF) attacks
        $SQL = "SELECT SacCode FROM Partner WHERE id = " . $_SESSION[PartnerID];
        $query = mysql_query($SQL);
        $sacode = mysql_fetch_array($query);
        //print_r($sacode);echo "<br>";
        $SQL1 = "SELECT show_gplink FROM SacCodePartners WHERE SacCodePartners = '" . $sacode['SacCode'] . "'";
        $query1 = mysql_query($SQL1);
        $gp_link = mysql_fetch_array($query1);
        if (isset($_POST['token_phtest']) && $_POST['token_phtest'] != $_SESSION['token_phtest']) {
            //if(time() > $_SESSION['token_timestamp'] + 1440){
            header($_SERVER['SERVER_PROTOCOL'] . ' 403 Forbidden');
            Header("Location: ../../../404page.php");
            //echo "<html><head><title>CSRF attack</title></head><body>CSRF attack.</body></html>";
            //}
        }
        /* else{            
          header($_SERVER['SERVER_PROTOCOL'] . ' 403 Forbidden');
          Header( "Location: ../../../404page.php" );
          //echo "<html><head><title>CSRF attack</title></head><body>CSRF attack.</body></html>";
          } */
        screen_save_blood_pressure_multi();
        screen_save_cholesterol();
        screen_save_blood_glucose();
        screen_save_height_weight();

        $Error = false;
        $sql = "SELECT * FROM TestTypeCompLink INNER JOIN TestComps ON TestComps.TestCompID = TestTypeCompLink.CompID WHERE TestTypeID = " . $_SESSION['TestTypeSearch'];
        $recordset = mysql_query($sql);

        //get testtype id for pru vaitality brand  
        /* $sqltesttype = "SELECT id FROM TestTypes WHERE Name = 'Vitality Healthcheck' limit 1";
          $rectesttype = mysql_query($sqltesttype);
          $rowtesttype = mysql_fetch_array($rectesttype); */
        $testtypeid = $_SESSION['sactesttype'];

        //get componant id for pru vaitality brand
        $sqlcompo = "SELECT TestCompID  FROM TestComps WHERE TestCompName = 'Cotiniene' limit 1";
        $reccompo = mysql_query($sqlcompo);
        $rowcompo = mysql_fetch_array($reccompo);
        $compoid = $rowcompo['TestCompID'];

        //if($_SESSION['TestTypeSearch'] != $testtypeid){
        while ($row = mysql_fetch_array($recordset)) {
            if ($row[TestCompID] == 7) {
                $validatebp = validate_blood_pressure_multi();
                //if testtype is not belong to pruvitality.. date :11-02-2013
                if ($_SESSION['TestTypeSearch'] != $testtypeid) {
                    if ($validatebp == 'empty' || $validatebp == 'outofrange' || $validatebp == 'higherD') {//Add diastolic heigher condition #Santosh kumar #18-02-2013
                        $Error = true;
                    }
                } else {
                    if ($validatebp == 'empty' || $validatebp == 'outofrange' || $validatebp == 'higherD') {//Add diastolic heigher condition #Santosh kumar #18-02-2013
                        $Error = true;
                    }
                }
            } elseif ($row[TestCompID] == 4) {
                $validateCholesterolInput = validate_cholesterol_input();
                //if testtype is not belong to pruvitality.. date :11-02-2013
                if ($_SESSION['TestTypeSearch'] != $testtypeid) {
                    if ($validateCholesterolInput == 'empty' || $validateCholesterolInput == 'outofrange' || $validateCholesterolInput == 'higherD') {
                        $Error = true;
                    }
                } else {
                    if ($validateCholesterolInput == 'empty' || $validateCholesterolInput == 'outofrange' || $validateCholesterolInput == 'higherD') {
                        $Error = true;
                    }
                }
            } elseif ($row[TestCompID] == 1) {
                $validateBloodGlucoseInput = validate_blood_glucose_input();
                //if testtype is not belong to pruvitality.. date :11-02-2013
                if ($_SESSION['TestTypeSearch'] != $testtypeid) {
                    if ($validateBloodGlucoseInput == 'empty' || $validateBloodGlucoseInput == 'outofrange') {
                        $Error = true;
                    }
                } else {
                    if ($validateBloodGlucoseInput == 'empty' || $validateBloodGlucoseInput == 'outofrange') {
                        $Error = true;
                    }
                }
            } elseif ($row[TestCompID] == 10) {

                if (validate_height_weight_screen()) {
                    $validateHeightWeightScreen = validate_height_weight_screen();
                } else {
                    $validateHeightWeightScreen = validate_waist_hips_screen();
                }
                //if testtype is not belong to pruvitality.. date :11-02-2013
                if ($_SESSION['TestTypeSearch'] != $testtypeid) {
                    if ($validateHeightWeightScreen == 'empty' || $validateHeightWeightScreen == 'outofrange') {
                        $Error = true;
                    }
                } else {
                    //Added 18-02-2013
                    if ($validateHeightWeightScreen == 'empty' || $validateHeightWeightScreen == 'outofrange') {
                        $Error = true;
                    }
                }
            } elseif ($row[TestCompID] == $compoid) {
                //53 componantid
                #Start: 10 FEB 2016, Smoking declaration for PRU
                //$validatecotinieneInput = validate_cotiniene_input();
                $validatecotinieneInput = '';
                if ((isset($_POST['have_you_smoked']) && $_POST['have_you_smoked'] == 0)) {
                    $validatecotinieneInput = validate_cotiniene_input();
                }
                #End: 10 FEB 2016, Smoking declaration for PRU



                if ($validatecotinieneInput == 'notint') {
// 							   show_cotiniene_entry(true);
                    $Error = true;
                }
                //06112013 - ZD #517
                if ($validatecotinieneInput == 'outofrange') {
                    $Error = true;
                }
            }
        }
        // add on 20 feb 2015 due to mandatory validate request
        if (validate_signature() == false) {
            $Error = true;
        }
       // echo "reach my condintion";
        if ($_SESSION['TestTypeSearch'] == $testtypeid) {
            //echo "inside my condintion";
            $response=validate_waist_range();
            if($response==true){
                $Error = true;
            }
        }
//        if ($_SESSION['TestTypeSearch'] == $testtypeid) {
//            //echo "inside my condintion";
//            $response=validate_waist_range_with_BMI();
//            if($response==true){
//                $Error = true;
//            }
//        }

        // if ($_SESSION['TestTypeSearch'] != $testtypeid) {
//                              if($gp_link['show_gplink'] == 1){
//                              $check_validate = validate_clinical_follow();
//                              if($check_validate == 'empty'){
//                                       //     clinical_followup(true);
//                                            $Error = true;
//                                    }
//                              }
//           if (validate_signature() == false) {
//                $Error = true;
//            }
//        } else {
//                              if($gp_link['show_gplink'] == 1){
//                                $check_validate = validate_clinical_follow();
//                                if($check_validate == 'empty'){
//                                           // clinical_followup(true);
//                                            $Error = true;
//                                    }
//                              }
        //  if ($_POST['AuditSignature'] != "") {
//                if (validate_signature() == false) {
//                    $Error = true;
//                }
        //  }
//        }
        //}
        

        if ($Error == false) {
            //echo "<br>Hello";exit;
            $_SESSION['PharmTestStatus'] = "ValidateOK";
        } else {//echo "<br>Hello1";exit;
            $_SESSION['PharmTestStatus'] = "ValidateFalse";
        }
        #ZD#10558
        if (emptyOrNotWaistHips() == true) {
            $_SESSION['PharmTestStatus'] = "ValidateFalse";
        } elseif (emptyOrNotBpARM() == true) {
            $_SESSION['PharmTestStatus'] = "ValidateFalse";
        }
#ZD#10558 end
    } elseif ($_POST['amend'] == 'Amend biometrics') {
        $_SESSION['PharmTestStatus'] = "ValidateAmend";
        $_SESSION['estStatus'] = "";
    } elseif (isset($_POST['selectCustomer']) && $_POST['selectCustomer'] != "") {
        $_SESSION['SearchCXID'] = $_POST['selectCustomer'];
        $_SESSION['PharmTestStatus'] = "ChooseTest";
    } elseif ($_POST['cmdConfirmed']) {
        $_SESSION['PharmTestStatus'] = "START";
        $_SESSION['EditAppointmentID'] = "";
    } elseif ($_POST['cmdCancel']) {
        $_SESSION['PharmTestStatus'] = "START";
        $_SESSION['EditAppointmentID'] = "";
    } elseif ($_POST[btnCancelRegNewCustomer]) {
        $_SESSION['PharmTestStatus'] = "";
        $_SESSION['EditAppointmentID'] = "";
    } elseif ($_POST[btnCancel]) {
        $_SESSION['PharmTestStatus'] = "START";
        $_SESSION['EditAppointmentID'] = "";
    } elseif ($_SESSION['TestTypeSearch'] == 1) {
        
    } else {
        //$_SESSION['PharmTestStatus'] = "START";
    }

    //redirections
    if ($_SESSION['PharmTestStatus'] == "ShowTests") {
        if ($_SERVER['HTTP_HOST'] == 'www.dev.roadtohealth.co.uk' || $_SERVER['HTTP_HOST'] == 'www.qa1.roadtohealth.co.uk') {
            $pru_testtype = '9235'; #QA Test type

            $GLU_ID = '7';
            $CHOL_ID = '4';
            $BP_ID = '1';
            $HW_ID = '10';
        } else if ($_SERVER['HTTP_HOST'] == "172.10.1.6:8658") {
            $pru_testtype = '220'; #local

            $GLU_ID = '1';
            $CHOL_ID = '4';
            $BP_ID = '26';
            $HW_ID = '10';
        } else {
            $pru_testtype = '98'; #Live Test type 

            $GLU_ID = '7';
            $CHOL_ID = '4';
            $BP_ID = '1';
            $HW_ID = '10';
        }

        $componentOrders = array('one' => $GLU_ID, 'two' => $CHOL_ID, 'three' => $BP_ID, 'four' => $HW_ID);

        echo "<div class='carryout-col1'>";
        //echo "<div id='show_common_error'> </div>";
        //echo "cxid :".$_SESSION[CustAppointmentID];
        //echo "<pre>";print_r($_SESSION);echo "</pre>";
        //get componant id for pru vaitality brand
        $sqlcompo = "SELECT TestCompID  FROM TestComps WHERE TestCompName = 'Cotiniene' limit 1";
        $reccompo = mysql_query($sqlcompo);
        $rowcompo = mysql_fetch_array($reccompo);
        $compoid = $rowcompo['TestCompID'];

        //get testtype id for pru vaitality brand
        /* $sqltesttype = "SELECT id FROM TestTypes WHERE Name = 'Vitality Healthcheck' limit 1";
          $rectesttype = mysql_query($sqltesttype);
          $rowtesttype = mysql_fetch_array($rectesttype); */
        $testtypeid = $_SESSION['sactesttype'];

        $recordn = mysql_query("SELECT * FROM CustAppointments WHERE CustAppointmentsID = " . $_SESSION[CustAppointmentID]);
        $rown = mysql_fetch_array($recordn);
        if ($_SESSION['TestTypeSearch'] == $testtypeid && $rown['Attended'] == 'Yes') {

            $record = mysql_query("SELECT * FROM CustAppointments WHERE CustAppointmentsID = " . $_SESSION[CustAppointmentID]);

            while ($row = mysql_fetch_array($record)) {
                $_SESSION['TestTypeSearch'] = $row['TestTypeID'];
                $_SESSION['SearchCXID'] = $row['CxID'];
            }


            $sql = "SELECT * FROM TestTypeCompLink INNER JOIN TestComps ON TestComps.TestCompID = TestTypeCompLink.CompID WHERE TestTypeID = " . $_SESSION['TestTypeSearch'];

            $recordset = mysql_query($sql);

            //print($sql);

            while ($row = mysql_fetch_array($recordset)) {

                if ($row[TestCompID] == 7) {       //echo "inside";
                    $_SESSION['bpm'] = db_get_previous_BloodPressure($_SESSION['SearchCXID']);
                    // print_r($_SESSION['bpm']);
                    show_blood_pressure_multi_entry(false);
                } elseif ($row[TestCompID] == 4) {

                    $_SESSION[chol] = db_get_previous_cholesterol($_SESSION['SearchCXID']);
                    show_cholesterol_entry(false);
                } elseif ($row[TestCompID] == 1) {
                    $_SESSION[bg] = db_get_previous_blood_glucose($_SESSION['SearchCXID']);
                    show_blood_glucose_entry(false);
                } elseif ($row[TestCompID] == 10) {
                    if ($PartnerID[id] = 241) {
                        $_SESSION['BMClass'] = db_get_previous_body_mass_result2($_SESSION['SearchCXID']);
                        show_height_weight_entry_nostyles_basic(false);
                    }
                } elseif ($row[TestCompID] == $compoid) {
                    $_SESSION['cotiniene'] = db_get_previous_cotiniene($_SESSION['SearchCXID']);
                    show_cotiniene_entry(false);
                }
            }
            $AuditSignature = db_get_previous_Signature($_SESSION[CustAppointmentID]);
            $SQL = "SELECT SacCode FROM Partner WHERE id = " . $_SESSION[PartnerID];
            $query = mysql_query($SQL);
            $sacode = mysql_fetch_array($query);
            //print_r($sacode);echo "<br>";
//                                          $SQL1 = "SELECT show_gplink FROM SacCodePartners WHERE SacCodePartners = '" . $sacode['SacCode']."'";
//                                          $query1 = mysql_query($SQL1);
//                                          $gp_link = mysql_fetch_array($query1);
//                                          if($gp_link['show_gplink'] == 1){
//                                            $clinical_follow = db_get_previous_clinical_followup($_SESSION[CustAppointmentID]);
//                                            clinical_followup(false,$clinical_follow);
//                                          }
            show_signature(false, $AuditSignature);
        } else {

            $sql = "SELECT * FROM TestTypeCompLink INNER JOIN TestComps ON TestComps.TestCompID = TestTypeCompLink.CompID WHERE TestTypeID = " . $_SESSION['TestTypeSearch'] . " ORDER BY TestTypeID";

            $recordset = mysql_query($sql);

            #Continine removal
            if ($_SESSION['TestTypeSearch'] == $testtypeid) {
                show_cotiniene_entry(false);
            }

            $componentOrderArray = array();
            $componentUnorderArray = array();
            while ($row = mysql_fetch_array($recordset)) {
                if (in_array($row['CompID'], $componentOrders)) {
                    $arrCom = array_keys($componentOrders, $row['CompID']);
                    $compId = isset($arrCom[0]) ? $arrCom[0] : '';
                    switch ($compId) {
                        case 'one':
                            $componentOrderArray[0] = $row;
                            break;
                        case 'two':
                            $componentOrderArray[1] = $row;
                            break;
                        case 'three':
                            $componentOrderArray[3] = $row;
                            break;
                        case 'four':
                            $componentOrderArray[4] = $row;
                            break;
                        default:
                            $componentUnorderArray[] = $row;
                            break;
                    }
                } else {
                    $componentUnorderArray[] = $row;
                }
            }

            ksort($componentOrderArray);
            $componentArray = array_merge($componentOrderArray, $componentUnorderArray);
            foreach ($componentArray as $row) {

                if ($row[TestCompID] == $BP_ID) {
                    show_blood_pressure_multi_entry(false);
                } elseif ($row[TestCompID] == $CHOL_ID) {
                    show_cholesterol_entry(false);
                } elseif ($row[TestCompID] == $GLU_ID) {
                    show_blood_glucose_entry(false);
                } elseif ($row[TestCompID] == $HW_ID) {
                    if ($PartnerID[id] = 241) {
                        /* if(db_get_previous_body_mass_result2($_SESSION['SearchCXID']))
                          {
                          $_SESSION['BMClass'] = db_get_previous_body_mass_result2($_SESSION['SearchCXID']);
                          }
                          else {unset($_SESSION['BMClass']);} */
                        show_height_weight_entry_nostyles_basic(false);
                    }
                } /* elseif ($row[TestCompID] == $compoid) {
                  //53 co,ponantid

                  show_cotiniene_entry(false);
                  } */ # Continine removal
            }
            $SQL = "SELECT SacCode FROM Partner WHERE id = " . $_SESSION[PartnerID];
            $query = mysql_query($SQL);
            $sacode = mysql_fetch_array($query);
            //print_r($sacode);echo "<br>";
//                                                        $SQL1 = "SELECT show_gplink FROM SacCodePartners WHERE SacCodePartners = '" . $sacode['SacCode']."'";
//                                                        $query1 = mysql_query($SQL1);
//                                                        $gp_link = mysql_fetch_array($query1);
//                                                        if($gp_link['show_gplink'] == 1){
//                                                          clinical_followup(false);
//                                                        }

            show_signature(false);
        }

        /* echo "<table width='300px'>";
          echo "<tr>";
          echo "<td width='10px' class='$SigError'></td><td colspan='3' ><h2>Check Carried Out By</h2></td>";
          echo "</tr>";
          echo "<tr><td></td>";
          echo "<td width='146px' style='font-weight:bold'>Initials</td>";
          echo "<td width='50px'><input tabindex='12' style='width:40px'  type='text' name='AuditSignature' autocomplete='off' value='".$_POST[AuditSignature]."' ></td>";
          echo "</tr>";
          echo "</table>"; */

        show_buttons("btnUpdateFunction");
        echo "</div>";

        require_once("../vhqv2/FullPharmacistTests/RTHv2/TestInfomationScreen.php");
    } elseif ($_SESSION['PharmTestStatus'] == "ValidateFalse") {
        if ($_SERVER['HTTP_HOST'] == 'www.dev.roadtohealth.co.uk' || $_SERVER['HTTP_HOST'] == 'www.qa1.roadtohealth.co.uk' || $_SERVER['HTTP_HOST'] == 'qa1.roadtohealth.co.uk') {
            $testtypeid = '9235'; #QA Test type

            $GLU_ID = '7';
            $CHOL_ID = '4';
            $BP_ID = '1';
            $HW_ID = '10';
        } else if ($_SERVER['HTTP_HOST'] == "172.10.1.6:8658") {
            $testtypeid = '220'; #local

            $GLU_ID = '1';
            $CHOL_ID = '4';
            $BP_ID = '26';
            $HW_ID = '10';
        } else {
            $testtypeid = '98'; #Live Test type

            $GLU_ID = '7';
            $CHOL_ID = '4';
            $BP_ID = '1';
            $HW_ID = '10';
        }
        $componentOrders = array('one' => $GLU_ID, 'two' => $CHOL_ID, 'three' => $BP_ID, 'four' => $HW_ID);

        #Cotinine removal
        //get componant id for pru vaitality brand
//        $sqlcompo = "SELECT TestCompID  FROM TestComps WHERE TestCompName = 'Cotiniene' limit 1";
//        $reccompo = mysql_query($sqlcompo);
//        $rowcompo = mysql_fetch_array($reccompo);
//        $compoid = $rowcompo['TestCompID'];
        //get testtype id for pru vaitality brand Date : 11-02-2013
        /* $sqltesttype = "SELECT id FROM TestTypes WHERE Name = 'Vitality Healthcheck' limit 1";
          $rectesttype = mysql_query($sqltesttype);
          $rowtesttype = mysql_fetch_array($rectesttype); */
        $testtypeid = $_SESSION['sactesttype'];

        echo "<div class='carryout-col1'>";

        echo "<div id='show_common_error'> </div>";

        $Error = false;
        $sql = "SELECT * FROM TestTypeCompLink INNER JOIN TestComps ON TestComps.TestCompID = TestTypeCompLink.CompID WHERE TestTypeID = " . $_SESSION['TestTypeSearch'];
        $recordset = mysql_query($sql);

//print($sql);
        if ($_SESSION['TestTypeSearch'] == $testtypeid) {
            $validatecotinieneInput = validate_cotiniene_input();

            if ($validatecotinieneInput == 'notint') {
                show_cotiniene_entry(true);
                $Error = true;
            } elseif ($validatecotinieneInput == 'outofrange') {
                show_cotiniene_entry(true);
                $Error = true;
            } else {
                show_cotiniene_entry(false);
            }
        }

        $componentOrderArray = array();
        $componentUnorderArray = array();
        while ($row = mysql_fetch_array($recordset)) {
            if (in_array($row['CompID'], $componentOrders)) {
                $arrCom = array_keys($componentOrders, $row['CompID']);
                $compId = isset($arrCom[0]) ? $arrCom[0] : '';
                switch ($compId) {
                    case 'one':
                        $componentOrderArray[0] = $row;
                        break;
                    case 'two':
                        $componentOrderArray[1] = $row;
                        break;
                    case 'three':
                        $componentOrderArray[3] = $row;
                        break;
                    case 'four':
                        $componentOrderArray[4] = $row;
                        break;
                    default:
                        $componentUnorderArray[] = $row;
                        break;
                }
            } else {
                $componentUnorderArray[] = $row;
            }
        }

        ksort($componentOrderArray);
        $componentArray = array_merge($componentOrderArray, $componentUnorderArray);

        foreach ($componentArray as $row) {

            if ($row[TestCompID] == $BP_ID) {
                /* if(validate_blood_pressure_multi() == false)
                  {
                  show_blood_pressure_multi_entry(true);
                  }
                  else
                  {
                  show_blood_pressure_multi_entry(false);
                  } */
                $validateBP = validate_blood_pressure_multi();
                //if testtype is not belong to pruvitality.. date :11-02-2013
                if ($_SESSION['TestTypeSearch'] == $testtypeid) {
                    if ($validateBP == 'empty' || $validateBP == 'outofrange' || $validateBP == 'higherD') {
                        show_blood_pressure_multi_entry(true);
                        $Error = true;
                    } else {
                        show_blood_pressure_multi_entry(false);
                    }
                } else {
                    if ($validateBP == 'empty' || $validateBP == 'outofrange' || $validateBP == 'higherD') {
                        show_blood_pressure_multi_entry(true);
                        $Error = true;
                    } else {
                        show_blood_pressure_multi_entry(false);
                    }
                }
            } elseif ($row[TestCompID] == $CHOL_ID) {
                $validateCholesterolInput = validate_cholesterol_input();
                //echo $validateCholesterolInput."hello";
                //if testtype is not belong to pruvitality.. date :11-02-2013
                if ($_SESSION['TestTypeSearch'] == $testtypeid) {
                    if ($validateCholesterolInput == 'empty' || $validateCholesterolInput == 'outofrange' || $validateCholesterolInput == 'higherD') {
                        show_cholesterol_entry(true);
                        $Error = true;
                    } else {
                        show_cholesterol_entry(false);
                    }
                } else {
                    if ($validateCholesterolInput == 'empty' || $validateCholesterolInput == 'outofrange' || $validateCholesterolInput == 'higherD') {
                        show_cholesterol_entry(true);
                        $Error = true;
                    } else {
                        show_cholesterol_entry(false);
                    }
                }
            } elseif ($row[TestCompID] == $GLU_ID) {

                $validateBloodGlucoseInput = validate_blood_glucose_input();
                //if testtype is not belong to pruvitality.. date :11-02-2013
                if ($_SESSION['TestTypeSearch'] == $testtypeid) {
                    if ($validateBloodGlucoseInput == 'empty' || $validateBloodGlucoseInput == 'outofrange') {
                        show_blood_glucose_entry(true);
                        $Error = true;
                    } else {
                        show_blood_glucose_entry(false);
                    }
                } else {
                    if ($validateBloodGlucoseInput == 'empty' || $validateBloodGlucoseInput == 'outofrange') {
                        show_blood_glucose_entry(true);
                        $Error = true;
                    } else {
                        show_blood_glucose_entry(false);
                    }
                }
            } elseif ($row[TestCompID] == $HW_ID) {

                $b = validate_height_weight_screen();
                if ($b != "") {
                    $validateHeightWeightScreen = validate_height_weight_screen();
                } else {
                    $validateHeightWeightScreen = validate_waist_hips_screen();
                }
                // echo "0".$validateHeightWeightScreen;
                //if testtype is not belong to pruvitality.. date :11-02-2013
                if ($_SESSION['TestTypeSearch'] == $testtypeid) { // echo "1";
                    if ($validateHeightWeightScreen == 'empty' || $validateHeightWeightScreen == 'outofrange') {
                        // echo "2";
                        show_height_weight_entry_nostyles_basic(true);
                        $Error = true;
                    } else {
                        if (db_get_previous_body_mass_result2($_SESSION['SearchCXID'])) {
                            // 13082013 - Added comment for previous values - ZD #349 
                            //$_SESSION['BMClass'] = db_get_previous_body_mass_result2($_SESSION['SearchCXID']);
                        }
                        show_height_weight_entry_nostyles_basic(false);
                    }
                } else {



                    if ($validateHeightWeightScreen == 'empty' || $validateHeightWeightScreen == 'outofrange') {
                        show_height_weight_entry_nostyles_basic(true);
                        $Error = true;
                    } else {
                        if (db_get_previous_body_mass_result2($_SESSION['SearchCXID'])) {
                            //$_SESSION['BMClass'] = db_get_previous_body_mass_result2($_SESSION['SearchCXID']);
                        }
                        show_height_weight_entry_nostyles_basic(false);
                    }
                }
            } /* elseif ($row[TestCompID] == $compoid) {
              //53 co,ponantid
              $validatecotinieneInput = validate_cotiniene_input();

              if ($validatecotinieneInput == 'notint') {
              show_cotiniene_entry(true);
              $Error = true;
              } elseif ($validatecotinieneInput == 'outofrange') {
              show_cotiniene_entry(true);
              $Error = true;
              } else {
              show_cotiniene_entry(false);
              }
              } */#Cotinine removal
        }
        $SQL = "SELECT SacCode FROM Partner WHERE id = " . $_SESSION[PartnerID];
        $query = mysql_query($SQL);
        $sacode = mysql_fetch_array($query);
        //print_r($sacode);echo "<br>";
        $SQL1 = "SELECT show_gplink FROM SacCodePartners WHERE SacCodePartners = '" . $sacode['SacCode'] . "'";
        $query1 = mysql_query($SQL1);
        $gp_link = mysql_fetch_array($query1);

        if ($_SESSION['TestTypeSearch'] != $testtypeid) {
//                                   if($gp_link['show_gplink'] == 1){
//                                   $check_validate = validate_clinical_follow();
//                                if($check_validate == 'empty'){
//                                                    clinical_followup(true);
//						    $Error = true;
//                                            }else{
//                                                //echo "mehta";
//                                                $followvalue = $_POST['cfradio'];
//                                                clinical_followup(false,$followvalue);
//                                            }
//                                   }
            if (validate_signature() == false) {
                show_signature(true);
                $Error = true;
            } else {
                show_signature(false);
            }
        } else {
//                              if($gp_link['show_gplink'] == 1){
//                              $check_validate = validate_clinical_follow();
//                                if($check_validate == 'empty'){
//                                                    clinical_followup(true);
//						    $Error = true;
//                                            }else{
//                                                //echo "priyesh";
//                                                $followvalue = $_POST['cfradio'];
//                                                clinical_followup(false,$followvalue);
//                                            }
//                              }
            if ($_POST['AuditSignature'] != "") {
                if (validate_signature() == false) {
                    show_signature(true);
                    $Error = true;
                } else {
                    show_signature(false);
                }
            } else {
                show_signature(false);
            }
        }


        /* echo "<table width='300px'>";
          echo "<tr>";
          echo "<td width='10px' class='$SigError'></td><td colspan='3' ><h2>Completion Signature</h2></td>";
          echo "</tr>";
          echo "<tr><td></td>";
          echo "<td width='146px' style='font-weight:bold'>Initials</td>";
          echo "<td width='50px'><input tabindex='12' style='width:40px'  type='text' name='AuditSignature' autocomplete='off' value='".$_POST[AuditSignature]."' ></td>";
          echo "</tr>";
          echo "</table>"; */



        show_buttons("btnUpdateFunction");
        echo '</div>';
        require_once("../vhqv2/FullPharmacistTests/RTHv2/TestInfomationScreen.php");
        //echo "</form>";
    } elseif ($_SESSION['PharmTestStatus'] == "ValidateAmend") {
        #Cotinine removal
        if ($_SERVER['HTTP_HOST'] == 'www.dev.roadtohealth.co.uk' || $_SERVER['HTTP_HOST'] == 'www.qa1.roadtohealth.co.uk' || $_SERVER['HTTP_HOST'] == 'qa1.roadtohealth.co.uk') {
            $testtypeid = '9235'; #QA Test type

            $GLU_ID = '7';
            $CHOL_ID = '4';
            $BP_ID = '1';
            $HW_ID = '10';
        } else if ($_SERVER['HTTP_HOST'] == "172.10.1.6:8658") {
            $testtypeid = '220'; #local

            $GLU_ID = '1';
            $CHOL_ID = '4';
            $BP_ID = '26';
            $HW_ID = '10';
        } else {
            $testtypeid = '98'; #Live Test type

            $GLU_ID = '7';
            $CHOL_ID = '4';
            $BP_ID = '1';
            $HW_ID = '10';
        }

        $componentOrders = array('one' => $GLU_ID, 'two' => $CHOL_ID, 'three' => $BP_ID, 'four' => $HW_ID);

        //get componant id for pru vaitality brand
//        $sqlcompo = "SELECT TestCompID  FROM TestComps WHERE TestCompName = 'Cotiniene' limit 1";
//        $reccompo = mysql_query($sqlcompo);
//        $rowcompo = mysql_fetch_array($reccompo);
//        $compoid = $rowcompo['TestCompID'];

        echo "<div class='carryout-col1'>";
        $Error = false;

        $record = mysql_query("SELECT * FROM CustAppointments WHERE CustAppointmentsID = " . $_SESSION[CustAppointmentID]);


        while ($row = mysql_fetch_array($record)) {

            $_SESSION['TestTypeSearch'] = $row['TestTypeID'];
            $_SESSION['SearchCXID'] = $row['CxID'];
        }

        $sql = "SELECT * FROM TestTypeCompLink INNER JOIN TestComps ON TestComps.TestCompID = TestTypeCompLink.CompID WHERE TestTypeID = " . $_SESSION['TestTypeSearch'];

        $recordset = mysql_query($sql);

        $componentOrderArray = array();
        $componentUnorderArray = array();
        while ($row = mysql_fetch_array($recordset)) {
            if (in_array($row['CompID'], $componentOrders)) {
                $arrCom = array_keys($componentOrders, $row['CompID']);
                $compId = isset($arrCom[0]) ? $arrCom[0] : '';
                switch ($compId) {
                    case 'one':
                        $componentOrderArray[0] = $row;
                        break;
                    case 'two':
                        $componentOrderArray[1] = $row;
                        break;
                    case 'three':
                        $componentOrderArray[3] = $row;
                        break;
                    case 'four':
                        $componentOrderArray[4] = $row;
                        break;
                    default:
                        $componentUnorderArray[] = $row;
                        break;
                }
            } else {
                $componentUnorderArray[] = $row;
            }
        }

        ksort($componentOrderArray);
        $componentArray = array_merge($componentOrderArray, $componentUnorderArray);

//print($sql);
        #Cotinine Removal  
        if ($_SESSION['TestTypeSearch'] == $testtypeid) {
            // $_SESSION['cotiniene'] = db_get_previous_cotiniene($_SESSION['SearchCXID']);
            show_cotiniene_entry(false);
        }
        foreach ($componentArray as $row) {
            if ($row[TestCompID] == $BP_ID) {       //echo "inside";
                $_SESSION['bpm'] = db_get_previous_BloodPressure($_SESSION['SearchCXID']);
                // print_r($_SESSION['bpm']);
                show_blood_pressure_multi_entry(false);
            } elseif ($row[TestCompID] == $CHOL_ID) {

                $_SESSION[chol] = db_get_previous_cholesterol($_SESSION['SearchCXID']);
                show_cholesterol_entry(false);
            } elseif ($row[TestCompID] == $GLU_ID) {
                $_SESSION[bg] = db_get_previous_blood_glucose($_SESSION['SearchCXID']);
                show_blood_glucose_entry(false);
            } elseif ($row[TestCompID] == $HW_ID) {
                if ($PartnerID[id] = 241) {
                    $_SESSION['BMClass'] = db_get_previous_body_mass_result2($_SESSION['SearchCXID']);
                    show_height_weight_entry_nostyles_basic(false);
                }
            } /* elseif ($row[TestCompID] == $compoid) {
              $_SESSION['cotiniene'] = db_get_previous_cotiniene($_SESSION['SearchCXID']);
              show_cotiniene_entry(false);
              } */ #Cotinine removal
        }
        $AuditSignature = db_get_previous_Signature($_SESSION[CustAppointmentID]);
        $SQL = "SELECT SacCode FROM Partner WHERE id = " . $_SESSION[PartnerID];
        $query = mysql_query($SQL);
        $sacode = mysql_fetch_array($query);
        //print_r($sacode);echo "<br>";
//                $SQL1 = "SELECT show_gplink FROM SacCodePartners WHERE SacCodePartners = '" . $sacode['SacCode']."'";
//                $query1 = mysql_query($SQL1);
//                $gp_link = mysql_fetch_array($query1);
//                if($gp_link['show_gplink'] == 1){
//                  $clinical_follow = db_get_previous_clinical_followup($_SESSION[CustAppointmentID]);
//                  clinical_followup(false,$clinical_follow);
//                }

        show_signature(false, $AuditSignature);



        show_buttons("btnUpdateFunction");
        echo '</div>';
        require_once("../vhqv2/FullPharmacistTests/RTHv2/TestInfomationScreen.php");
        //echo "</form>";
    } elseif ($_SESSION['PharmTestStatus'] == "ValidateOK") {

        if ($_SERVER['HTTP_HOST'] == 'www.dev.roadtohealth.co.uk' || $_SERVER['HTTP_HOST'] == 'www.qa1.roadtohealth.co.uk' || $_SERVER['HTTP_HOST'] == 'qa1.roadtohealth.co.uk') {
            //$testtypeid = '9235'; #QA Test type

            $GLU_ID = '7';
            $CHOL_ID = '4';
            $BP_ID = '1';
            $HW_ID = '10';
        } else if ($_SERVER['HTTP_HOST'] == "172.10.1.6:8658") {
            //$testtypeid = '220'; #local

            $GLU_ID = '1';
            $CHOL_ID = '4';
            $BP_ID = '26';
            $HW_ID = '10';
        } else {
            // $testtypeid = '98'; #Live Test type

            $GLU_ID = '7';
            $CHOL_ID = '4';
            $BP_ID = '1';
            $HW_ID = '10';
        }
        $componentOrders = array('one' => $GLU_ID, 'two' => $CHOL_ID, 'three' => $BP_ID, 'four' => $HW_ID);

        $SQL = "SELECT SacCode FROM Partner WHERE id = " . $_SESSION[PartnerID];
        $query = mysql_query($SQL);
        $sacode = mysql_fetch_array($query);
        //print_r($sacode);echo "<br>";
        $SQL1 = "SELECT show_gplink FROM SacCodePartners WHERE SacCodePartners = '" . $sacode['SacCode'] . "'";
        $query1 = mysql_query($SQL1);
        $gp_link = mysql_fetch_array($query1);

        $sql = "SELECT * FROM TestTypeCompLink INNER JOIN TestComps ON TestComps.TestCompID = TestTypeCompLink.CompID WHERE TestTypeID = " . $_SESSION['TestTypeSearch'];
        $recordset = mysql_query($sql);

        $componentOrderArray = array();
        $componentUnorderArray = array();
        while ($row = mysql_fetch_array($recordset)) {
            if (in_array($row['CompID'], $componentOrders)) {
                $arrCom = array_keys($componentOrders, $row['CompID']);
                $compId = isset($arrCom[0]) ? $arrCom[0] : '';
                switch ($compId) {
                    case 'one':
                        $componentOrderArray[0] = $row;
                        break;
                    case 'two':
                        $componentOrderArray[1] = $row;
                        break;
                    case 'three':
                        $componentOrderArray[3] = $row;
                        break;
                    case 'four':
                        $componentOrderArray[4] = $row;
                        break;
                    default:
                        $componentUnorderArray[] = $row;
                        break;
                }
            } else {
                $componentUnorderArray[] = $row;
            }
        }

        ksort($componentOrderArray);
        $componentArray = array_merge($componentOrderArray, $componentUnorderArray);

        //get testtype id for pru vaitality brand
        /* $sqltesttype = "SELECT id FROM TestTypes WHERE Name = 'Vitality Healthcheck' limit 1";
          $rectesttype = mysql_query($sqltesttype);
          $rowtesttype = mysql_fetch_array($rectesttype); */
        $testtypeid = $_SESSION['sactesttype'];

        #Cotinine Removal
        //get componant id for pru vaitality brand
//        $sqlcompo = "SELECT TestCompID  FROM TestComps WHERE TestCompName = 'Cotiniene' limit 1";
//        $reccompo = mysql_query($sqlcompo);
//        $rowcompo = mysql_fetch_array($reccompo);
//        $compoid = $rowcompo['TestCompID'];
        //comment date :12-02-2013 =>start
        //if($_SESSION['TestTypeSearch'] != $testtypeid){
        $validateBP = validate_blood_pressure_multi();
        $validateHR = validate_hr();
        $validateCholesterolInput = validate_cholesterol_input();
        $validateBloodGlucoseInput = validate_blood_glucose_input();
        $validateGlucosFastingInput = validate_glucose_fasting_input();
        $validateHeightWeightScreen = validate_height_weight_screen();
        $validateWaistHipsScreen = validate_waist_hips_screen();
        $validatecotinieneInput = validate_cotiniene_input();
//        }else{
// 	$validateBP = "";
// 	$validateHR = "";
// 	$validateCholesterolInput = "";
// 	$validateBloodGlucoseInput = "";
// 	$validateGlucosFastingInput = "";
// 	$validateHeightWeightScreen = "";
// 	$validateWaistHipsScreen = "";
// 	}
        #Cotinine removal
        if ($_SESSION['TestTypeSearch'] == $testtypeid && ($validatecotinieneInput != 'outofrange' || $validatecotinieneInput != 'notint')) {
            db_insert_cotiniene($_SESSION['SearchCXID'], "Pharmacist Results");
        }

        foreach ($componentArray as $row) {


            if (($row[TestCompID]) == $BP_ID && ($validateBP != 'empty' || $_SESSION['TestTypeSearch'] == $testtypeid)) {
                db_insert_blood_pressure_multi($_SESSION['SearchCXID'], "Pharmacist Results");
                //audit
                $s = getLatestIDFromTableViaCxID($_SESSION['SearchCXID'], "eHRBloodPressure");
                $alog->audit($Partner['id'], 'Insert', 'eHRBloodPressure', "Pharmacist Blood Pressure Update", $s);
            } elseif (($row[TestCompID] == $CHOL_ID) && (($validateCholesterolInput != 'empty' || $_SESSION['TestTypeSearch'] == $testtypeid) && $validateCholesterolInput != 'outofrange')) {
                db_insert_cholesterol($_SESSION['SearchCXID'], "Pharmacist Results");
                //audit
                $s = getLatestIDFromTableViaCxID($_SESSION['SearchCXID'], "eHRCholesterol");
                $alog->audit($Partner['id'], 'Insert', 'eHRCholesterol', "Pharmacist Cholesterol Update", $s);
            } elseif (($row[TestCompID] == $GLU_ID) && (($validateBloodGlucoseInput != 'empty' || $_SESSION['TestTypeSearch'] == $testtypeid) && $validateBloodGlucoseInput != 'outofrange')) {
                db_insert_blood_glucose($_SESSION['SearchCXID'], "Pharmacist Results");
                //audit
                $s = getLatestIDFromTableViaCxID($_SESSION['SearchCXID'], "eHRGlucose");
                $alog->audit($Partner['id'], 'Insert', 'eHRGlucose', "Pharmacist Blood Glucose Update", $s);
            } elseif (($row[TestCompID] == $HW_ID) && (($validateHeightWeightScreen != 'empty' || $_SESSION['TestTypeSearch'] == $testtypeid) && $validateHeightWeightScreen != 'outofrange')) {
                $_SESSION[CxID] = $_SESSION['SearchCXID'];
                db_insert_height_weight(get_body_mass_screen_data_metric(), "Pharmacist");
                //audit
                $s = getLatestIDFromTableViaCxID($_SESSION['SearchCXID'], "CustPrimaryWeight");
                $alog->audit($Partner['id'], 'Insert', 'CustPrimaryWeight', "Pharmacist Weight and Height Update", $s);
            } /* elseif ($row[TestCompID] == $compoid && ($validatecotinieneInput != 'outofrange' || $validatecotinieneInput != 'notint')) {
              db_insert_cotiniene($_SESSION['SearchCXID'], "Pharmacist Results");
              } */ # Cotinine removal
        }


        //comment date :12-02-2013 =>End

        if (validate_signature() == false) {
            $_SESSION['AuditSignature'] = trim($_POST['AuditSignature']);
            $Error = true;
        } else {
            $_SESSION['AuditSignature1'] = trim($_POST['AuditSignature']);
            $AuditSignature = trim($_POST['AuditSignature']);
            $a = mysql_query("UPDATE CustAppointments SET BiometricsDataSent='No',DNA = '2', branch_cancellation_id = '0',Attended = 'Yes', AuditSignature = '" . $AuditSignature . "'  WHERE CustAppointmentsID = " . $_SESSION[CustAppointmentID]);
        }
//        if($gp_link['show_gplink'] == 1){
//        $check_validate = validate_clinical_follow();
//            if ($check_validate == 'empty') 
//            {
//                    $Error = true;
//            } else {
//                    if($_POST['cfradio'] != ''){
//                        $clinical_followup = $_POST['cfradio'];
//                    }
//                        $a = mysql_query("UPDATE CustAppointments SET clinical_followup = '".$clinical_followup."'  WHERE CustAppointmentsID = " . $_SESSION[CustAppointmentID]);
//              }
//        }

        if ($_SESSION['TestTypeSearch'] == $testtypeid) {

            $_SESSION['AuditSignature1'] = trim($_POST['AuditSignature']);
            $AuditSignature = trim($_POST['AuditSignature']);
//                            if($_POST['cfradio'] != ''){
//                                $clinical_followup = $_POST['cfradio'];
//                            }
            $a = mysql_query("UPDATE CustAppointments SET BiometricsDataSent='No',DNA = '2',branch_cancellation_id = '0',Attended = 'Yes', AuditSignature = '" . $AuditSignature . "'  WHERE CustAppointmentsID = " . $_SESSION[CustAppointmentID]);
        } else {
//                            if($gp_link['show_gplink'] == 1){
//                            $check_validate = validate_clinical_follow();
//                            if ($check_validate == 'empty') 
//                            {
//                                    $Error = true;
//                            } else {
//                                    if($_POST['cfradio'] != ''){
//                                        $clinical_followup = $_POST['cfradio'];
//                                    }
//                                   $a = mysql_query("UPDATE CustAppointments SET clinical_followup = '".$clinical_followup."'  WHERE CustAppointmentsID = " . $_SESSION[CustAppointmentID]);
//
//                            }
//                            }

            if (validate_signature() == false) {
                $_SESSION['AuditSignature'] = trim($_POST['AuditSignature']);
                $Error = true;
            } else {
                $_SESSION['AuditSignature1'] = trim($_POST['AuditSignature']);
                $AuditSignature = trim($_POST['AuditSignature']);
//                                    if($_POST['cfradio'] != ''){
//                                        $clinical_followup = $_POST['cfradio'];
//                                    }
                $a = mysql_query("UPDATE CustAppointments SET BiometricsDataSent='No',DNA = '2',branch_cancellation_id = '0',Attended = 'Yes', AuditSignature = '" . $AuditSignature . "'  WHERE CustAppointmentsID = " . $_SESSION[CustAppointmentID]);
            }
        }

// 	unset_blood_pressure_multi();
// 	unset_blood_glucose();
// 	unset_cholesterol();
        //Update QScore
        //CaculateQPositionFromData($_SESSION['SearchCXID']);
        $ConfirmedCustomer = getRow(Customer, CustomerID, $_SESSION[SearchCXID]);
        $Cx = getRow(Customer, CustomerID, $ConfirmedCustomer[CustomerID]);
        $record = mysql_query("SELECT * FROM CustAppointments WHERE CustAppointmentsID = " . $_SESSION[CustAppointmentID]);
        while ($row = mysql_fetch_array($record)) {
            $WhatTestTypeID = $row[TestTypeID];
        }

// Added on 23 March 2011
        require_once("../cxroutines/ActionsPrimary.php");
// EOF Added on 23 March 2011
        if ($WhatTestTypeID == 44 || $WhatTestTypeID == 2 || $WhatTestTypeID == 97 || $WhatTestTypeID == $testtypeid) { //date : 18-02-2013
            require_once("../calculators/getANewQApp.php");
        } else { //else part added on 02-05-2012 for healthpoints issue
            //work out and update customers healthpoints for haveing completed pharmacy check
            $Updated = mktime();
            $CustHealthPoints = getRow(CustHealthPoints, CxID, $ConfirmedCustomer[CustomerID]);
            //$HealthPoints = getRow(TestTypes,id,$WhatTestTypeID);
            $HealthPoints = getRow(HealthPointAward, HealthPointAwardID, 3);
            $HPTotal = $CustHealthPoints[TotalEarned] + $HealthPoints[Points]; //$HealthPoints[HealthPoints]
            $HPAvailable = $CustHealthPoints[Available] + $HealthPoints[Points];
            mysql_query("UPDATE CustHealthPoints SET TotalEarned='$HPTotal', Available='$HPAvailable', Updated='$Updated'  WHERE CxID = '$ConfirmedCustomer[CustomerID]'");
            $HealthPointsLL = runSQLString("INSERT INTO CustHealthPointsLinkList(CxID,HealthPointID,Awarded)
		VALUES('" . $ConfirmedCustomer[CustomerID] . "','3','$Updated')");
            //end of healthpoints routine
        }

        $_SESSION['PharmTestStatus'] = "ShowConfirm";
        require_once("../vhqv2/FullPharmacistTests/RTHv2/Confirm.php");
    } elseif ($_SESSION['PharmTestStatus'] == "ValidateSave") {

        if ($_SESSION['HTTP_HOST'] == ' www.dev.roadtohealth.co.uk') {
            $pru_testtype = '9235'; #QA Test type
        } elseif ($_SERVER['HTTP_HOST'] == '172.10.1.6:8658') {
        $pru_testtype = '220'; #Live Test type
        }else {
            $pru_testtype = '98'; #Live Test type
        }

        $sql = "SELECT * FROM TestTypeCompLink INNER JOIN TestComps ON TestComps.TestCompID = TestTypeCompLink.CompID WHERE TestTypeID = " . $_SESSION['TestTypeSearch'];
        $recordset = mysql_query($sql);

        //get testtype id for pru vaitality brand
        /* $sqltesttype = "SELECT id FROM TestTypes WHERE Name = 'Vitality Healthcheck' limit 1";
          $rectesttype = mysql_query($sqltesttype);
          $rowtesttype = mysql_fetch_array($rectesttype); */
        $testtypeid = $_SESSION['sactesttype'];

        //get componant id for pru vaitality brand
        $sqlcompo = "SELECT TestCompID  FROM TestComps WHERE TestCompName = 'Cotiniene' limit 1";
        $reccompo = mysql_query($sqlcompo);
        $rowcompo = mysql_fetch_array($reccompo);
        $compoid = $rowcompo['TestCompID'];
//comments Date :12-02-2013 => Start
        //if($_SESSION['TestTypeSearch'] != $testtypeid){
        $validateBP = validate_blood_pressure_multi();
        $validateHR = validate_hr();
        $validateCholesterolInput = validate_cholesterol_input();
        $validateBloodGlucoseInput = validate_blood_glucose_input();
        $validateGlucosFastingInput = validate_glucose_fasting_input();
        $validateHeightWeightScreen = validate_height_weight_screen();
        $validateWaistHipsScreen = validate_waist_hips_screen();
        $validatecotinieneInput = validate_cotiniene_input();
// 	}else{
// 	$validateBP = "";
// 	$validateHR = "";
// 	$validateCholesterolInput = "";
// 	$validateBloodGlucoseInput = "";
// 	$validateGlucosFastingInput = "";
// 	$validateHeightWeightScreen = "";
// 	$validateWaistHipsScreen = "";
// 	}

        while ($row = mysql_fetch_array($recordset)) {
            if (($row[TestCompID] == 7) && ($validateBP != 'empty' || $_SESSION['TestTypeSearch'] == $testtypeid)) {

                db_insert_blood_pressure_multi($_SESSION['SearchCXID'], "Pharmacist Results");
                //audit
                $s = getLatestIDFromTableViaCxID($_SESSION['SearchCXID'], "eHRBloodPressure");
                $alog->audit($Partner['id'], 'Insert', 'eHRBloodPressure', "Pharmacist Blood Pressure Update", $s);
            } elseif (($row[TestCompID] == 4) && (($validateCholesterolInput != 'empty' || $_SESSION['TestTypeSearch'] == $testtypeid) && $validateCholesterolInput != 'outofrange')) {

                db_insert_cholesterol($_SESSION['SearchCXID'], "Pharmacist Results");
                //audit
                $s = getLatestIDFromTableViaCxID($_SESSION['SearchCXID'], "eHRCholesterol");
                $alog->audit($Partner['id'], 'Insert', 'eHRCholesterol', "Pharmacist Cholesterol Update", $s);
            } elseif (($row[TestCompID] == 1) && (($validateBloodGlucoseInput != 'empty' || $_SESSION['TestTypeSearch'] == $testtypeid) && $validateBloodGlucoseInput != 'outofrange')) {

                db_insert_blood_glucose($_SESSION['SearchCXID'], "Pharmacist Results");
                //audit
                $s = getLatestIDFromTableViaCxID($_SESSION['SearchCXID'], "eHRGlucose");
                $alog->audit($Partner['id'], 'Insert', 'eHRGlucose', "Pharmacist Blood Glucose Update", $s);
            } elseif (($row[TestCompID] == 10 ) && (($validateHeightWeightScreen != 'empty' || $_SESSION['TestTypeSearch'] == $testtypeid) && $validateHeightWeightScreen != 'outofrange')) {

                $_SESSION[CxID] = $_SESSION['SearchCXID'];
                db_insert_height_weight(get_body_mass_screen_data_metric(), "Pharmacist");
                //audit
                $s = getLatestIDFromTableViaCxID($_SESSION['SearchCXID'], "CustPrimaryWeight");
                $alog->audit($Partner['id'], 'Insert', 'CustPrimaryWeight', "Pharmacist Weight and Height Update", $s);
            } elseif ($row[TestCompID] == $compoid && ($validatecotinieneInput != 'outofrange' || $validatecotinieneInput != 'notint')) {
                db_insert_cotiniene($_SESSION['SearchCXID'], "Pharmacist Results");
                //audit
                //$s = getLatestIDFromTableViaCxID($_SESSION['SearchCXID'],"eHRGlucose");
                //$alog->audit( $Partner['id'], 'Insert', 'eHRGlucose' , "Pharmacist Blood Glucose Update",$s);
            }
        }

        if ($_SESSION['TestTypeSearch'] == $testtypeid) {
            $_SESSION['AuditSignature1'] = trim($_POST['AuditSignature']);
            $AuditSignature = $_POST['AuditSignature'];
//                            if($_POST['cfradio'] != ""){
//                                $clinical_followup = $_POST['cfradio'];
//                            }

            $a = mysql_query("UPDATE CustAppointments SET BiometricsDataSent='No',DNA = '2', branch_cancellation_id = '0',Attended = 'Yes', AuditSignature = '" . $AuditSignature . "'  WHERE CustAppointmentsID = " . $_SESSION[CustAppointmentID]);
        } else {


            $AuditSignature = trim($_POST['AuditSignature']);
            $_SESSION['AuditSignature1'] = trim($_POST['AuditSignature']);
//                            if($_POST['cfradio'] != ""){
//                                $clinical_followup = $_POST['cfradio'];
//                            }
            $a = mysql_query("UPDATE CustAppointments SET BiometricsDataSent='No',DNA = '2',branch_cancellation_id = '0',Attended = 'Yes', AuditSignature = '" . $AuditSignature . "'  WHERE CustAppointmentsID = " . $_SESSION[CustAppointmentID]);
        }
//comments Date :12-02-2013 => End
        unset_blood_pressure_multi();
        unset_blood_glucose();
        unset_cholesterol();
        if ($_SESSION['CustAppBrandName'] == "Lag") {
            mysql_close($link);
            connectToDemoDevDB();
            $query = "SELECT * FROM Customer where CustomerID='" . $_SESSION['SearchCXID'] . "'";
            //$ConfirmedCustomer = getRow(Customer,CustomerID,$_SESSION[SearchCXID]);
            $rescust = mysql_query($query);
            $ConfirmedCustomer = mysql_fetch_array($rescust);
            mysql_close($dlink2);
            connectToDB();
        } else {
            $ConfirmedCustomer = getRow(Customer, CustomerID, $_SESSION[SearchCXID]);
        }
        if ($_SESSION['CustAppBrandName'] == "Lag") {
            mysql_close($link);
            connectToDemoDevDB();
            $query = "SELECT * FROM Customer where CustomerID='" . $ConfirmedCustomer['CustomerID'] . "'";
            //$ConfirmedCustomer = getRow(Customer,CustomerID,$_SESSION[SearchCXID]);
            $rescustnew = mysql_query($query);
            $Cx = mysql_fetch_array($rescustnew);
            mysql_close($dlink2);
            connectToDB();
        } else {
            $Cx = getRow(Customer, CustomerID, $ConfirmedCustomer[CustomerID]);
        }

        $record = mysql_query("SELECT * FROM CustAppointments WHERE CustAppointmentsID = " . $_SESSION[CustAppointmentID]);
        while ($row = mysql_fetch_array($record)) {

            $WhatTestTypeID = $row[TestTypeID];
        }
// Added on 23 March 2011
        require_once("../cxroutines/ActionsPrimary.php");
// EOF Added on 23 March 2011
        if ($WhatTestTypeID == 44 || $WhatTestTypeID == 2 || $WhatTestTypeID == 97 || $WhatTestTypeID == $testtypeid) { //date : 18-02-2013
            require_once("../calculators/getANewQApp.php");
        } else { //else part added on 02-05-2012 for healthpoints issue
            //work out and update customers healthpoints for haveing completed pharmacy check
            $Updated = mktime();
            $CustHealthPoints = getRow(CustHealthPoints, CxID, $ConfirmedCustomer[CustomerID]);
            //$HealthPoints = getRow(TestTypes,id,$WhatTestTypeID);
            $HealthPoints = getRow(HealthPointAward, HealthPointAwardID, 3);
            $HPTotal = $CustHealthPoints[TotalEarned] + $HealthPoints[Points]; //$HealthPoints[HealthPoints]
            $HPAvailable = $CustHealthPoints[Available] + $HealthPoints[Points];
            mysql_query("UPDATE CustHealthPoints SET TotalEarned='$HPTotal', Available='$HPAvailable', Updated='$Updated'  WHERE CxID = '$ConfirmedCustomer[CustomerID]'");
            $HealthPointsLL = runSQLString("INSERT INTO CustHealthPointsLinkList(CxID,HealthPointID,Awarded)
		VALUES('" . $ConfirmedCustomer[CustomerID] . "','3','$Updated')");
            //end of healthpoints routine
        }
        //Update QScore
        //CaculateQPositionFromData($_SESSION['SearchCXID']);
        $_SESSION['PharmTestStatus'] = "";
        $succesMsg = true;

        header('Location:/vhqv2/index.php');
        //require_once("../vhq/index.php");
    } elseif ($_SESSION['PharmTestStatus'] == "ShowConfirm") {

        /* =========//Functionality to redirect on 404 page if appointment id is not exists into database //=========== */
        $appid = $_SESSION['CustAppointmentID'];
        $record = mysql_query("SELECT * FROM CustAppointments WHERE CustAppointmentsID ='" . $appid . "'");
        if (mysql_num_rows($record) == 0) {
            //If appointment is not exist into database then this page will redirect on 404 page.
            header('Location: ../404page.php');
        }
        /* ====================== */
        /* ====== Query use to get the appointment Location id============= */
        $appid = $_SESSION['CustAppointmentID'];
        $AppLocQuery = "SELECT LocID,AppClinics.ClinID,ClinicRooms.AppRoomID FROM `CustAppointments` INNER JOIN ClinicRooms ON ClinicRooms.AppRoomID = `CustAppointments`.`AppRoomID` INNER JOIN AppClinics ON AppClinics.ClinID = ClinicRooms.ClinId WHERE `CustAppointmentsID`='$appid'";
        $AppLocResult = mysql_query($AppLocQuery);
        $AppLocQueryArray = mysql_fetch_array($AppLocResult, MYSQL_ASSOC);
        $AppLocId = $AppLocQueryArray['LocID'];
        /* ================================================================= */
        //Functionality to get the partner clinics locations.
        $locationArray = array();
        $partnerLocations = "SELECT LocationID FROM PartnerLocationLinkList WHERE PartnerID ='" . $_SESSION['PartnerID'] . "'";
        $PartnerClinics = mysql_query($partnerLocations);
        //$PartnerClinicsArray=mysql_fetch_array($PartnerClinics);
        while ($row123 = mysql_fetch_array($PartnerClinics, MYSQL_ASSOC)) {
            array_push($locationArray, $row123['LocationID']);
        }
        if (!in_array($AppLocId, $locationArray)) {
            //if appoint location id is not match with partner location id the page will redirect on 404 page.
            header('Location: ../404page.php');
        }

        require_once("../vhqv2/FullPharmacistTests/RTHv2/Confirm.php");
    } elseif ($_SESSION['PharmTestStatus'] == "roadtohealthHRA") {
        require_once("$root/vhqv2/FullPharmacistTests/HRA/HRAprocessor.php");
    } elseif ($_SESSION['PharmTestStatus'] == "START") {

        $_SESSION['PharmTestStatus'] = "";
        header("Location: index.php") . SID;
    } else {
        $sql = "SELECT *, Locations.Name AS LocName FROM AppClinics
	INNER JOIN ClinicRooms ON AppClinics.ClinID = ClinicRooms.ClinID
	INNER JOIN LocationsRooms ON LocationsRooms.RoomID = ClinicRooms.RoomID
	INNER JOIN Locations ON AppClinics.LocID = Locations.LocationID
	WHERE";

        if ($_GET['passlocid'] != "") {
            $LocID = $_GET['passlocid'];
            $sql .= " Locations.LocationID = " . $_SESSION['LocID'] = $LocID;
        } else {
            $PartnerLocationLinkList = mysql_query("SELECT * FROM PartnerLocationLinkList WHERE PartnerID = " . $_SESSION['PartnerID']);
            $sql .= " (";
            while ($PartnerLocationLinkListRow = mysql_fetch_array($PartnerLocationLinkList)) {
                $sql .= " Locations.LocationID = " . $PartnerLocationLinkListRow[LocationID] . " OR";
                $_SESSION['LocID'] = $PartnerLocationLinkListRow[LocationID];
            }
            $sql = substr($sql, 0, strlen($sql) - 2);
            $sql .= ")";
        }


        /* if (isset($_SESSION['selectedCalDate']) && $_SESSION['selectedCalDate'] != '')
          $selectedDate = $_SESSION['selectedCalDate'];
          else */
        $selectedDate = date("Y-m-d", mktime());

        $sql .= " AND ClinDate = '" . $selectedDate . "' AND Status = 'Live'";
        $result = mysql_query($sql);

        $_SESSION[CorpClinicViewID] = "";

        if (mysql_num_rows($result) > 0) {
            while ($row = mysql_fetch_array($result)) {
                $_SESSION[CorpClinicViewID] = $row[ClinID];
            }
        }

        if ($_SESSION[CorpClinicViewID] != "") {
            require_once("Clinics.php");
        } else {
            echo "<h2>No clinics set-up for this date.</h2>";
        }
    }


    if ($showFormTag) {
        ?>
        <input type="hidden" value="<?php echo genTokenPhtest(); ?>" name="token_phtest">   
    </form>
        <?php
    }
    if (isset($succesMsg)) {
        echo "<h2>Records have been updated successfully!</h2>";
    }
    ?>
<div class="clear">
</div>
<script type="text/javascript">
<?php if (isset($succesMsg)) { ?>
        setTimeout('RedirectToHome()', 2000);
<?php } ?>

    function RedirectToHome() {
        location.href = '/vhqv2/index.php';
    }

</script>
