<?php
/**
 * Static content controller.
 *
 * This file will render views from views/pages/
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
App::uses('AppController', 'Controller');

/**
 * Static content controller
 *
 * Override this controller by placing a copy in controllers directory of an application
 *
 * @package       app.Controller
 * @link http://book.cakephp.org/2.0/en/controllers/pages-controller.html
 */
class ValidicController extends AppController {

    /**
     * This controller does not use a model
     *
     * @var array
     */
    var $uses = array('User', 'Weight', 'SleepUserAnswer', 'Challenge', 'SleepMatrix', 'UserPoint', 'SleepUserCompleted', 'Qscore', 'HraCategory', 'FitnessAnswer', 'Content', 'AcceptedChallenge','Device');
    var $components = array('RequestHandler', 'Session', 'Curl');

    /**
     * Displays a view
     *
     * @return void
     * @throws NotFoundException When the view file could not be found
     * 	or MissingViewException in debug mode.
     *  URL : https://api.validic.com/v1/organizations/579f87e3f77896000d000000/users.json
     *  Request : {
                "user": {
                  "uid": "03-K64-F"
                },
              "access_token": "62b023fc33545df43a531b65e573cfdfeb50e639b017be8ed727375d332f0b81"
              }

        Response : {
	"code": 201,
	"message": "Ok",
	"user": {
		"_id": "57d81e6eb8004a39dd000852",
		"uid": "03-K64-F",
		"access_token": "Bubbuye7RXW_Vj_bJkTf",
		"profile": null
	}
} 
     * {"code":201,"message":"Ok","user":{"_id":"57d822254068f0ed61000a27","uid":"57d697b7a66f91398d4ab8a0","access_token":"Xv-RqTHoKW2yGbzw-pVZ","profile":null}} // for user 57d697b7a66f91398d4ab8a0
     * kk202@yopmail.com 
     */
    public function RegisterUserOnValidic() {
        $this->autoRender = false;
        $this->layout = false;
        if ($this->request->is('post')) { 
            $UserID = $this->request->data['userId'];
            $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $UserID)));
            $requestArr['user']['uid'] = $UserData['User']['id'];
           // $requestArr['user']['uid'] = '57d697b7a66f91398d4ab8a0';
            $requestArr['access_token'] = ORGANIZATION_ACCESS_TOKEN;
            $requestJson = json_encode($requestArr);
            $url =  "https://api.validic.com/v1/organizations/".ORGANIZATION_ID."/users.json";
            $http_header = array('Content-Type:application/json');
            $output = $this->Curl->Connect($url, $http_header, true, $requestJson);
            
            //echo "<pre>";  
	    //print_r($output);exit;
	    if(!empty($output)){
		    $output = json_decode($output);
                   // print_r($output);die;
		if($output->code == 201){
			 $Devicetype = $this->request->data['device_type'];
			 $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $UserID)));
			 $data['user_id'] = $UserData['User']['id'];
			 $data['device_user_id'] = $output->user->_id;
			 $data['oauth_token'] = $output->user->access_token; 
			 $data['device_type'] = $Devicetype;
			 $data['timestamp'] = date('Y-m-d H:i:s');
			 $data['last_checked'] = date('Y-m-d H:i:s');
			 $data['status'] = 0;
			 if($this->Device->save($data)){
				 $response['status'] = '1';
				 $response['message'] = 'Device info saved successfully';
				 $response['device'] = $Devicetype;
				 echo json_encode($response);
			 }else{
				 $response['status'] = '0';
				 $response['message'] = 'Problem in saving user data';
				 echo json_encode($response);
			 }
		}else{
                    $response['status'] = '0';
                    $response['message'] = 'Some error occured from server, please try again';
                    echo json_encode($response); 
                }    
	    }
		
        }else{
		 $response['status'] = '0';
		 $response['message'] = 'Invalid user request';
		 echo json_encode($response); 
	  }
    }
    
   /* public function saveDeivceInfo(){
	 $this->autoRender = false;
         $this->layout = false;
	 $this->loadModel('User');
	 $this->loadModel('Device');
	  if ($this->request->is('post')) {
	 $User_id = $this->request->data['userId'];
	 $Devicetype = $this->request->data['device_type'];
         $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $User_id)));
	 $data['user_id'] = $UserData['User']['id'];
	 $data['device_type'] = $Devicetype;
	 $data['timestamp'] = date('Y-m-d H:i:s');
	 $data['last_checked'] = date('Y-m-d H:i:s');
	 $data['status'] = 1;
	 if($this->Device->save($data)){
		 $response['status'] = '1';
		 $response['message'] = 'Device info saved successfully';
		 $response['device'] = $Devicetype;
		 echo json_encode($response);
	 }else{
		 $response['status'] = '0';
		 $response['message'] = 'Error occured please try again';
		 echo json_encode($response);
	 }
	  }else{
		 $response['status'] = '0';
		 $response['message'] = 'Error occured please try again';
		 echo json_encode($response); 
	  }
}*/
    
    public function getRoutineData()
    {
        $this->autoRender = false; //  routine: calories + heartate + steps 
        $this->layout = false;
        $activity_Arr= array('Bicycling','Walking','Running');
        
        $requestArr['user']['uid'] = '57d822254068f0ed61000a27';
        $requestArr['access_token'] = ORGANIZATION_ACCESS_TOKEN;
        $startDate = '2016-09-22T00:00:01Z';
        $endDate = '2016-09-22T23:59:59Z';
        $requestJson = json_encode($requestArr);
        
         echo $url =  "https://api.validic.com/v1/organizations/".ORGANIZATION_ID."/users/".$requestArr['user']['uid']."/routine/latest.json?access_token=".$requestArr['access_token']."&start_date=".$startDate."&end_date=".$endDate."&limit=200&expanded=1";
       // $http_header = array("Content-Type:application/json");
       // $output = $this->Curl->Connect($url, $http_header, true, $requestJson);
        $opStr = file_get_contents($url);
        $opArr = json_decode($opStr,true); 
        $routineArr = $opArr['routine'];
        $resultArr = $this->processroutineArray($routineArr);  
        echo "<pre>";  print_r($resultArr);
      
        
    }
    
    
        public function getFitnessData()
    {
        $this->autoRender = false;
        $this->layout = false;
        //  routine: calories + heartate + steps + distence + duration
        
        $requestArr['user']['uid'] = '57d822254068f0ed61000a27';
        //$requestArr['user']['uid'] = '57d697b7a66f91398d4ab8a0';
        $requestArr['access_token'] = ORGANIZATION_ACCESS_TOKEN;
        $startDate = '2016-08-22T00:00:01Z';
        $endDate = '2016-09-22T23:59:59Z';
        $requestJson = json_encode($requestArr);
        //$url =  "https://api.validic.com/v1/organizations/".ORGANIZATION_ID."/users.json";
          echo $url =  "https://api.validic.com/v1/organizations/".ORGANIZATION_ID."/users/".$requestArr['user']['uid']."/fitness/latest.json?access_token=".$requestArr['access_token']."&start_date=".$startDate."&end_date=".$endDate."&limit=200&expanded=1";
        
//        $http_header = array('Content-Type:application/json');
//        $output = $this->Curl->Connect($url, $http_header, true, $requestJson);
//        echo "<pre>";            print_r($output);
        $opStr = file_get_contents($url);
        $opArr = json_decode($opStr,true); 
        //print_r($opArr);
        $fitnessArr = $opArr['fitness'];
        $resultArr = $this->processfitnessArray($fitnessArr); 
        echo "<pre>";  print_r($resultArr);
        
    }
    

 
public function processfitnessArray($fitnessArr){
    $i = 1;
        $finalArr = array();
        $activity_Arr = array('Bicycling','Walking','Running');
        foreach ($fitnessArr as $fitness) {
            //if(in_array($fitness['activity_category'], $activity_Arr)){
                
                $finalArr[$i]['activity_category'] = $fitness['activity_category'];
                $finalArr[$i]['ultra_lite'] = $fitness['activity_level'][0]['minutes'];
                $finalArr[$i]['lite'] = $fitness['activity_level'][1]['minutes'];
                $finalArr[$i]['moderate'] = $fitness['activity_level'][2]['minutes'];
                $finalArr[$i]['vigorous'] = $fitness['activity_level'][3]['minutes'];
                $finalArr[$i]['activity_name'] = $fitness['activity_name'];
                $finalArr[$i]['average_heart_rate'] = $fitness['average_heart_rate'];
                $finalArr[$i]['distance'] = $fitness['distance'];
                $finalArr[$i]['duration'] = $fitness['duration'];
                $finalArr[$i]['start_time'] = date("Y-M-d H:i:s",strtotime($fitness['start_time']));
                $newtime = strtotime($finalArr[$i]['start_time']);
                $newnewtime = $newtime + $fitness['duration'];
                $finalArr[$i]['end_time'] =  date("Y-M-d H:i:s",$newnewtime);
                $finalArr[$i]['calories'] = $fitness['calories'];
                $finalArr[$i]['steps'] = $fitness['steps'];
               // $finalArr[$i][''] = $fitness[''];
                 
                $i++;
            //}
        }
        return $finalArr;
}
public function processroutineArray($routineArr){
    $i = 1;
        $finalArr = array();
       
        foreach ($routineArr as $routine) {
                       
                $finalArr[$i]['calories'] = $routine['calories_burned'];
                $finalArr[$i]['ultra_lite'] = $routine['minutes_sedentary'];
                $finalArr[$i]['lite'] = $routine['minutes_lightly_active'];
                $finalArr[$i]['moderate'] = $routine['minutes_fairly_active'];
                $finalArr[$i]['vigorous'] = $routine['minutes_very_active'];
                $finalArr[$i]['start_time'] = date("Y-M-d H:i:s",strtotime($routine['timestamp']));
                $finalArr[$i]['end_time'] =  date("Y-M-d H:i:s",strtotime($routine['last_updated']));
                $finalArr[$i]['steps'] = $routine['steps'];
                        
                $i++;
        }
        return $finalArr;
}

public function checkUserRegister(){
	 $this->autoRender = false;
         $this->layout = false;
	 $this->loadModel('User');
	 $this->loadModel('Device');
	  if ($this->request->is('post')) {
	 $User_id = $this->request->data['userId'];
	 //$Devicetype = $this->request->data['device_type'];
         $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $User_id)));
	 $Ispresent = $this->Device->find('first', array('conditions' => array('Device.user_id' => $UserData['User']['id'])));
	 if(!empty($Ispresent)){
		$response['status'] = '1';
		 $response['message'] = 'User present';
		 $response['user_access_token'] = $Ispresent['Device']['oauth_token'];
		 $response['org_id'] = ORGANIZATION_ID;
		 $response['device_type'] = $Ispresent['Device']['device_type'];
                 $response['flag'] = $Ispresent['Device']['status'];
                 $response['user_id'] = $UserData['User']['id'];
		 echo json_encode($response); 
	 }else{
		 $response['status'] = '0';
		 $response['message'] = 'Error occured please try again';
                 $response['flag'] = '0';
		 echo json_encode($response);
	 }
}
}


public function setSource() {
        $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Device');
        if ($this->request->is('post')) {
            $User_id = $this->request->data['userId'];
            $source = $this->request->data['source'];
            $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $User_id)));
            $IsUserpresent = $this->Device->find('first', array('conditions' => array('Device.user_id' => $UserData['User']['id'])));
            if(!empty($IsUserpresent)){
                $this->Device->id = $IsUserpresent['Device']['device_id'];
            $saveData['status'] = $source;
            if($this->Device->save($saveData)){
                 $response['status'] = '1';
		 $response['message'] = 'status changed successfully';
		 echo json_encode($response);
            }else{
                $response['status'] = '0';
		 $response['message'] = 'Error while saving data';
		 echo json_encode($response);
            } 
            }else{
                $response['status'] = '0';
		 $response['message'] = 'Error while saving data';
		 echo json_encode($response);
            }
           
            
        }


    }
    
    public function checkConnection() {
         $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Device');
        if ($this->request->is('post')) {
        $User_id = $this->request->data['userId'];
         $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $User_id)));
         $deviceUserId = $this->Device->find('first', array('conditions' => array('Device.user_id' => $UserData['User']['id'])));
       // $requestArr['user']['uid'] = $deviceUserId['Device']['device_user_id'];
        $requestArr['user']['oauth_token'] = $deviceUserId['Device']['oauth_token'];
        $requestArr['access_token'] = ORGANIZATION_ACCESS_TOKEN;
        //$startDate = urlencode(date('Y-m-d 00:00:00'));
        //$endDate =   urlencode(date('Y-m-d 23:59:59')); name = "Garmin Connect" or name = "Fitbit"
        //$endDate =   '2016-09-29%2023:59:59';
       // $requestJson = json_encode($requestArr);
       // $url =  "https://api.validic.com/v1/organizations/".ORGANIZATION_ID."/users/".$requestArr['user']['uid']."/fitness/latest.json?access_token=".$requestArr['access_token']."&start_date=".$startDate."&end_date=".$endDate."&limit=200&expanded=1";
        $url =  "https://api.validic.com/v1/organizations/".ORGANIZATION_ID."/apps.json?authentication_token=".$requestArr['user']['oauth_token']."&access_token=".$requestArr['access_token'];
        
      // $http_header = array('Content-Type:application/json');
      //  $output = $this->Curl->Connect($url, $http_header, true, $requestJson);
        $output = file_get_contents($url);
        
        print_r($output);  
        }
    }

    public function saveStatus() {
           $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Device');
        if ($this->request->is('post')) {
        
         $User_id = $this->request->data['userId'];
         $status = $this->request->data['status'];
         $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $User_id)));
        $deviceUserId = $this->Device->find('first', array('conditions' => array('Device.user_id' => $UserData['User']['id'])));
        $this->Device->id = $deviceUserId['Device']['device_id'];
            $saveData['status'] = $status;
            if($this->Device->save($saveData)){
                 $response['status'] = '1';
		 $response['message'] = 'status changed successfully';
		 echo json_encode($response);
            }else{
                $response['status'] = '0';
		 $response['message'] = 'Error while saving data';
		 echo json_encode($response);
            } 
        }
    }
    
    public function unpairDevice() { 
         $this->autoRender = false;
        $this->layout = false;
        $this->loadModel('User');
        $this->loadModel('Device');
        if ($this->request->is('post')) {
            $User_id = $this->request->data['userId'];
            $targetURL = $this->request->data['targetURL'];
            $output = file_get_contents($targetURL);
            $opArr = json_decode($output,true);
            if($opArr['summary']['status'] == '200'){
                    $status = '0';
                    $UserData = $this->User->find('first', array('conditions' => array('User.user_id' => $User_id)));
                    $deviceUserId = $this->Device->find('first', array('conditions' => array('Device.user_id' => $UserData['User']['id'])));
                    $this->Device->id = $deviceUserId['Device']['device_id'];
                    $saveData['status'] = $status;
            if($this->Device->save($saveData)){
                 $response['status'] = '1';
		 $response['message'] = 'status changed successfully';
		 echo json_encode($response);
            }else{
                $response['status'] = '0';
		 $response['message'] = 'Error while saving data';
		 echo json_encode($response);
            } 
            }
        }
    }
    
    
}
?>



